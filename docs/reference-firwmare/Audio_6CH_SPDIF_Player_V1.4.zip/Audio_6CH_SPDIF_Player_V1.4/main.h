/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _MAIN_H
#define _MAIN_H

#include <stdbool.h>
#include "stm32f4xx.h"
#include "ff.h"
#include "mp3dec.h"
#include "wavparser.h"

//#define USB_ENABLED	1
//#define NOR_ENABLED	1

#define _NUM_CH	6
#define NOR_SECTOR_COUNT	8192	//256Mbit

#define KEEPALIVETIME	300

/* #define _VOLUME_STRS	"SD","USB","NOR" in ffconf.h */
#define strSDdrive	"SD:"
#define strUSBdrive	"USB:"
#define strNORdrive	"NOR:"

#define strConfigFile	"Config.txt"
#define strUSBupdateDIR	"USB:/UPLOAD"
#define strPromptDIR	"SD:/Prompts/"

#define SW1_Pin GPIO_Pin_4
#define SW1_GPIO_Port GPIOB
#define SW2_Pin GPIO_Pin_6
#define SW2_GPIO_Port GPIOB
#define SW3_Pin GPIO_Pin_8
#define SW3_GPIO_Port GPIOB
#define SW4_Pin GPIO_Pin_13
#define SW4_GPIO_Port GPIOC
#define SW5_Pin GPIO_Pin_14
#define SW5_GPIO_Port GPIOC
#define SW6_Pin GPIO_Pin_15
#define SW6_GPIO_Port GPIOC

#define SW7_Pin GPIO_Pin_0
#define SW7_GPIO_Port GPIOA
#define SW8_Pin GPIO_Pin_2
#define SW8_GPIO_Port GPIOA
#define SW9_Pin GPIO_Pin_4
#define SW9_GPIO_Port GPIOC

#define LED1_Pin GPIO_Pin_3
#define LED1_GPIO_Port GPIOB
#define LED2_Pin GPIO_Pin_5
#define LED2_GPIO_Port GPIOB
#define LED3_Pin GPIO_Pin_7
#define LED3_GPIO_Port GPIOB
#define LED4_Pin GPIO_Pin_0
#define LED4_GPIO_Port GPIOC
#define LED5_Pin GPIO_Pin_1
#define LED5_GPIO_Port GPIOC
#define LED6_Pin GPIO_Pin_2
#define LED6_GPIO_Port GPIOC

#define LED7_Pin GPIO_Pin_3
#define LED7_GPIO_Port GPIOC
#define LED8_Pin GPIO_Pin_1
#define LED8_GPIO_Port GPIOA
#define LED9_Pin GPIO_Pin_3
#define LED9_GPIO_Port GPIOA

#define SW_E_Pin GPIO_Pin_9
#define SW_E_GPIO_Port GPIOA
#define SW_S0_Pin GPIO_Pin_10
#define SW_S0_GPIO_Port GPIOA
#define SW_S1_Pin GPIO_Pin_11
#define SW_S1_GPIO_Port GPIOA
#define SW_S2_Pin GPIO_Pin_12
#define SW_S2_GPIO_Port GPIOA

#define SPI_CS_Pin GPIO_Pin_4
#define SPI_CS_GPIO_Port GPIOA
#define RST_Pin GPIO_Pin_0
#define RST_GPIO_Port GPIOB
#define U_Pin GPIO_Pin_10
#define U_GPIO_Port GPIOB
#define STATUS_LED_Pin GPIO_Pin_9
#define STATUS_LED_GPIO_Port GPIOB
#define SD_EN_Pin GPIO_Pin_7
#define SD_EN_GPIO_Port GPIOC
#define SD_CD_Pin GPIO_Pin_8
#define SD_CD_GPIO_Port GPIOA
#define INT_Pin GPIO_Pin_1
#define INT_GPIO_Port GPIOB
#define BLS_Pin GPIO_Pin_2
#define BLS_GPIO_Port GPIOB

#define LED_VOLUP_ON	LED8_GPIO_Port->BSRRL = LED8_Pin
#define LED_VOLUP_OFF	LED8_GPIO_Port->BSRRH = LED8_Pin
#define LED_VOLUP_STATE LED8_GPIO_Port->IDR & LED8_Pin

#define LED_VOLDN_ON	LED9_GPIO_Port->BSRRL = LED9_Pin
#define LED_VOLDN_OFF	LED9_GPIO_Port->BSRRH = LED9_Pin
#define LED_VOLDN_STATE LED9_GPIO_Port->IDR & LED9_Pin

#define SD_PWR_ON		SD_EN_GPIO_Port->BSRRL = SD_EN_Pin
#define SD_PWR_OFF		SD_EN_GPIO_Port->BSRRH = SD_EN_Pin
#define SD_PWR_STATE	SD_EN_GPIO_Port->IDR & SD_EN_Pin

#define COP_ON			STATUS_LED_GPIO_Port->BSRRL = STATUS_LED_Pin	/* COP = H */
#define COP_OFF			STATUS_LED_GPIO_Port->BSRRH = STATUS_LED_Pin	/* COP = L */
#define TOGGLE_COP_LED	STATUS_LED_GPIO_Port->ODR ^= STATUS_LED_Pin

#define VOL_UP			SW8_GPIO_Port->IDR & SW8_Pin
#define VOL_DN			SW9_GPIO_Port->IDR & SW9_Pin
#define CARD_DETECT		SD_CD_GPIO_Port->IDR & SD_CD_Pin

#define RST_OFF			RST_GPIO_Port->BSRRL = RST_Pin
#define RST_ON			RST_GPIO_Port->BSRRH = RST_Pin
#define DAC_MS_H		SPI_CS_GPIO_Port->BSRRL = SPI_CS_Pin
#define DAC_MS_L		SPI_CS_GPIO_Port->BSRRH = SPI_CS_Pin
#define LED_DEMO2_ON	LED7_GPIO_Port->BSRRL = LED7_Pin
#define LED_DEMO2_OFF	LED7_GPIO_Port->BSRRH = LED7_Pin
#define LED_DEMO2_STATE	LED7_GPIO_Port->IDR & LED7_Pin
#define DEMO2			SW7_GPIO_Port->IDR & SW7_Pin

#define SW_E_HIGH		SW_E_GPIO_Port->BSRRL = SW_E_Pin
#define SW_E_LOW		SW_E_GPIO_Port->BSRRH = SW_E_Pin

#define SD_SDIO_DMA_STREAM_RX         DMA2_Stream3
#define SD_SDIO_DMA_CHANNEL_RX        DMA_Channel_4
#define SD_SDIO_DMA_FLAG_FEIF_RX      DMA_FLAG_FEIF3
#define SD_SDIO_DMA_FLAG_DMEIF_RX     DMA_FLAG_DMEIF3
#define SD_SDIO_DMA_FLAG_TEIF_RX      DMA_FLAG_TEIF3
#define SD_SDIO_DMA_FLAG_HTIF_RX      DMA_FLAG_HTIF3
#define SD_SDIO_DMA_FLAG_TCIF_RX      DMA_FLAG_TCIF3
#define SD_SDIO_DMA_STREAM_TX         DMA2_Stream6
#define SD_SDIO_DMA_CHANNEL_TX        DMA_Channel_4
#define SD_SDIO_DMA_FLAG_FEIF_TX      DMA_FLAG_FEIF6
#define SD_SDIO_DMA_FLAG_DMEIF_TX     DMA_FLAG_DMEIF6
#define SD_SDIO_DMA_FLAG_TEIF_TX      DMA_FLAG_TEIF6
#define SD_SDIO_DMA_FLAG_HTIF_TX      DMA_FLAG_HTIF6
#define SD_SDIO_DMA_FLAG_TCIF_TX      DMA_FLAG_TCIF6

#define NOR_SPI_DR	*(__IO uint8_t *) 0x4001300C	//SPI1
#define NOR_SPI_SR	*(__IO uint8_t *) 0x40013008	//SPI1 SPI1->SR
#define NOR_SPI_CS_HIGH		GPIOA->BSRRL = GPIO_Pin_4
#define NOR_SPI_CS_LOW		GPIOA->BSRRH = GPIO_Pin_4

/* Flags use Bit Banding to avoid using bit set and bit clear, since it's not atomic, read-modify-write */
#define bbSCAN_KEYS_FLAG		(*(__IO uint32_t*)(SRAM1_BB_BASE))
#define	bbSET_LEDS_FLAG			(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000004))
#define	bbTOGGLE_LED_FLAG		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000008))
#define	bbPLAY_WAVE_FLAG		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x0000000C))
#define	bbTOGGLE_BUFFER_FLAG	(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000010))
#define	bbBUFFER_FULL_FLAG		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000014))
#define	bbBUFFER2_FULL_FLAG		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000018))
#define	bbMONO_TOGGLE_FLAG		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x0000001C))
#define	bbPROMPT_FLAG			(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000020))

#define	bbSD_CONNECT_STATE		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000080))
#define	bbNOR_CONNECT_STATE		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000084))
#define	bbUSB_CONNECT_STATE		(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000088))
#define	bbSD_INITIALIZE_STATE	(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x0000008C))
#define	bbNOR_INITIALIZE_STATE	(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000090))
#define	bbUSB_INITIALIZE_STATE	(*(__IO uint32_t*)(SRAM1_BB_BASE + 0x00000094))

#define BB_CLEAR_BIT	((uint32_t)0x00000000)
#define BB_SET_BIT		((uint32_t)0x00000001)

#define BitSet(A,k)     (A |= (1 << k))
#define BitClear(A,k)   (A &= ~(1 << k))
#define BitTest(A,k)    (A & (1 << k))

#define MAXTRACKS	30

typedef enum
{
	SCAN_KEYS_FLAG		= 0x00000001,
	SET_LEDS_FLAG		= 0x00000002,
	TOGGLE_LED_FLAG		= 0x00000004,
	PLAY_WAVE_FLAG		= 0x00000008,
	TOGGLE_BUFFER_FLAG	= 0x00000010,
	BUFFER_FULL_FLAG	= 0x00000020,
	BUFFER2_FULL_FLAG	= 0x00000040,
	MONO_TOGGLE_FLAG	= 0x00000080,
	PROMPT_FLAG			= 0x00000100,
	MAX_FLAG			= 0x80000000
}APP_FLAGS;

typedef enum
{
	NO_MEDIA_INIT	= 0x00000000,
	SD_CONNECT		= 0x00000001,
	NOR_CONNECT		= 0x00000002,
	USB_CONNECT		= 0x00000004,
	SD_INITIALIZE	= 0x00000008,
	NOR_INITIALIZE	= 0x00000010,
	USB_INITIALIZE	= 0x00000020,
	MAX_MEDIA_STATE	= 0x80000000
}MEDIA_STATE;

typedef enum
{
	UP = 0,
	DOWN
}KEY_STATE;

typedef enum
{
	IDLE_STATE = 0,
	MOUNT_DRIVE,
	OPEN_CONFIG,
	OPEN_TRACK,
	OPEN_FILE,
	READ_WAV_HEADER,
	FRAME_SYNC_FIND,
	FILE_READ,
	WAV_DECODE,
	MP3_DECODE,
	PLAY_CURRENT_FILE,
	PLAY_NEXT_FILE,
	PLAYBACK_STOP,
	PLAYBACK_PAUSE

}DECODE_STATE;

typedef enum
{
	DECODE_USB = 0,
	MOUNT_USB_DRIVE,
	FIND_TRACKS,
	MOUNT_NOR_DRIVE,
	FORMAT_NOR,
	COPY_TO_NOR,
	DONE_STATE,
	ERROR_STATE

}MEDIA_COPY_STATE;

typedef enum
{
	ENTER_STATE = 0,
	ENTER_VOLDN_STATE,
	PROG_MODE,
	VER_MAJOR,
	VER_MINOR,
	PROG_TRACK,
	DEFAULT_VOL,
	DEFAULT_VOL_SET,
	DEFAULT_VOL_CHANGE,
	DEFAULT_VOL_CHANGE_WAIT,
	DEFAULT_VOL_INPUT,
	DEFAULT_VOL_SCROLL,
	DEFAULT_VOL_SAVE,
	EXIT_PROG_INACTIVITY,
	EXIT_STATE

}PROMPT_STATE;

typedef struct
{
	GPIO_TypeDef* KeyGPIO[_NUM_CH];
	GPIO_TypeDef* LEDGPIO[_NUM_CH];
	uint16_t KeyGPIOpin[_NUM_CH];
	uint16_t LEDGPIOpin[_NUM_CH];
	uint8_t PlayCounter[_NUM_CH];
	uint8_t LastPlayCounter[_NUM_CH];
	KEY_STATE keyState[_NUM_CH];
	bool PlayState[_NUM_CH];
}CH_INFO;

typedef union
{
	uint8_t v[7 + _NUM_CH];
	struct
	{
		uint8_t DefaultVolume;
		uint8_t MinVolume;
		uint8_t MaxVolume;
		bool ButtonFlashLED;
		bool SimultaneousOutput;
		uint8_t PlayTimeSec;
		uint8_t DefVolTimeSec;
		uint8_t AttLevel[_NUM_CH];
	};
}CONFIG_INFO;

typedef struct
{
	__IO uint8_t ResetVolCounter;
	__IO uint8_t StopTimeSec;
	__IO uint8_t PromptTimeSec;
	__IO uint8_t PromptEnterExitTimeSec;
	__IO uint8_t PauseTimeoutSec;
	__IO uint16_t KeepAliveCounter;
}ONE_SECOND_COUNTERS;

typedef struct
{
	DECODE_STATE Decode_State;
	DECODE_STATE Last_Decode_State;
	MEDIA_COPY_STATE Media_Copy_State;
	PROMPT_STATE Prompt_State;
	ONE_SECOND_COUNTERS One_Second_Counters;
	__IO uint8_t OutputVolumelevel;
	__IO MEDIA_STATE* Media_State;
	__IO APP_FLAGS* Flags;
	FATFS *pFATFS;
	FIL *pFIL;
	const TCHAR* pDrive;
	float OutputAttLevel;
	CH_INFO CH_info;
	CONFIG_INFO Config_info;
	FATFS fs4K;				/* File system object 4K sector size*/
	FATFSmin fs512;			/* File system object 512 Byte sector size*/
	FIL fil4K;				/* File object 4K sector size*/
	FILmin fil512;     		/* File object 512 Byte sector size*/
} APP_PLAYER, *pAPP_PLAYER;

#if	USB_ENABLED
#include "usbh_core.h"
extern USB_OTG_CORE_HANDLE USB_OTG_Core;
extern USBH_HOST USB_Host;
#endif


void ClearFlags(void);
void USB_Event(void);
void WriteDIT4096(uint8_t reg, uint8_t data);

#endif /* _MAIN_H */
