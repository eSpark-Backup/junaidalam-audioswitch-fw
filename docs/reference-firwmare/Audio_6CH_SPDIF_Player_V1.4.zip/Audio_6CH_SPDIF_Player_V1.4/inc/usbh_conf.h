/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USBH_CONF__H__
#define __USBH_CONF__H__

#define USBH_MAX_NUM_ENDPOINTS                2
#define USBH_MAX_NUM_INTERFACES               2

#define USBH_MSC_MPS_SIZE                 0x40

#define USBH_MAX_DATA_BUFFER              0x400

#endif //__USBH_CONF__H__
