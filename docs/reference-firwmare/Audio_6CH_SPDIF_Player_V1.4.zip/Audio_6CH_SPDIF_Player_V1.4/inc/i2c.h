
#ifndef _I2C_H
#define _I2C_H

#include "stm32f4xx.h"
#include "stm32f4xx_i2c.h"

uint8_t I2C_ReadTransfer(I2C_TypeDef* Open_I2C, uint8_t dev_addr, uint8_t *buffer, uint32_t cnt, uint32_t ptr, uint8_t ptrlen);
uint8_t I2C_WriteTransfer(I2C_TypeDef* Open_I2C, uint8_t dev_addr, uint8_t *buffer, uint32_t cnt, uint32_t ptr, uint8_t ptrlen);

#endif /*_I2C_H*/
