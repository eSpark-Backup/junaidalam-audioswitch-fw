#define WRITE_HEADER		0x00
#define READ_HEADER			0x80

#define TRANS_CONTROL_REG	0x01

#define PWR_CLK_CONTROL_REG	0x02

#define ASP_CONTROL_REG		0x03

#define INT_STATUS_REG		0x04

#define INT_MASK_REG		0x05

#define INT_MODE_REG		0x06

#define BUF_TRANS_REG		0x07
