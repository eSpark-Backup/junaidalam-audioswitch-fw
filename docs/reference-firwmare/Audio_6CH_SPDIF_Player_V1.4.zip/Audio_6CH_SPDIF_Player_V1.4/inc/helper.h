/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _HELPER_H
#define _HELPER_H

void StrLower(char str[]);

#endif /* _HELPER_H */
