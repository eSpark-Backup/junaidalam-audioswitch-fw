#ifndef INC_BOARD_CONF_H_
#define INC_BOARD_CONF_H_

#include "main.h"

void SD_LowLevel_DMA_RxConfig(uint32_t *BufferDST, uint32_t BufferSize);
void SD_LowLevel_DMA_TxConfig(uint32_t *BufferSRC, uint32_t BufferSize);

void RCC_Configuration(void);
void GPIO_Configuration(void);
void I2S_Configuration(uint32_t AudioFreq);
void SPI_Configuration(void);
void SDIO_Configuration(void);
void TIM3_Configuration(void);
void TIM9_Configuration(void);
void TIM10_Configuration(void);
void TIM11_Configuration(void);
void WDG_Configuration(void);
void SD_on(void);
void SD_off(void);

#endif /* INC_BOARD_CONF_H_ */
