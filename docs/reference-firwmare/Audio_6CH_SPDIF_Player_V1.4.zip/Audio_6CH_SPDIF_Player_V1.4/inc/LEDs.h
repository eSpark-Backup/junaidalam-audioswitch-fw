#ifndef INC_LEDS_H_
#define INC_LEDS_H_

#include "main.h"

void SetCOPLED(APP_PLAYER *app);
uint32_t SetButtonLEDs(APP_PLAYER *app, uint32_t led_flag);

#endif /* INC_LEDS_H_ */
