/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USB_CONF__H__
#define __USB_CONF__H__

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"

#define USE_USB_OTG_FS
#define USB_OTG_FS_CORE

#define RX_FIFO_FS_SIZE			128
#define TXH_NP_FS_FIFOSIZ		96
#define TXH_P_FS_FIFOSIZ		96

#define USE_HOST_MODE

#define __ALIGN_BEGIN
#define __ALIGN_END

#define __packed    __attribute__((__packed__))

#endif //__USB_CONF__H__
