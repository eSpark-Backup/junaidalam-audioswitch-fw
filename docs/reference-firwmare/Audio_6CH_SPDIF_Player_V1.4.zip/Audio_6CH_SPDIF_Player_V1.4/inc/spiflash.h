
#include "stm32f4xx.h"

uint8_t SPIflashReadBytes(uint8_t *pBuffer,uint32_t ReadAddr,uint32_t NumByteToRead);
uint8_t SPIflashWriteSector(uint8_t *pBuffer, uint32_t WriteAddr, uint32_t NumSectorToWrite);
uint32_t SPIflashReadID(void);
void WriteDone(void);
