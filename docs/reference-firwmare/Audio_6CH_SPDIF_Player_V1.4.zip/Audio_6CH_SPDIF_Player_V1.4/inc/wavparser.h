
#ifndef _WAVPARSER_H
#define _WAVPARSER_H

#include "stm32f4xx.h"
#include "ff.h"

typedef struct {
	//uint32_t ChunkSize;
	uint32_t NumChannels;
	uint32_t SampleRate;
	//uint32_t ByteRate;
	//uint32_t BlockAlign;
	uint32_t BitsPerSample;
	uint32_t DataLen;
	//uint32_t DataStart;
} WAV_FMT;

uint8_t parse_wave_header(FIL * sf, WAV_FMT* wav_fmt);

#endif	/* _WAVPARSER_H */
