#ifndef INC_PROMPT_H_
#define INC_PROMPT_H_

#include "main.h"

void PromptScanButtons(APP_PLAYER *app);
void PromptSetButtonLEDs(APP_PLAYER *app);

#endif /* INC_PROMPT_H_ */
