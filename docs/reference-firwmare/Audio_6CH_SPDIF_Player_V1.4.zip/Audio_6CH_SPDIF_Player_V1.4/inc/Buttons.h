#ifndef INC_BUTTONS_H_
#define INC_BUTTONS_H_

#include "main.h"

void ScanButtons(APP_PLAYER *app);

#endif /* INC_BUTTONS_H_ */
