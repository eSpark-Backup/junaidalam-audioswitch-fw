#ifndef INC_DECODE_H_
#define INC_DECODE_H_

#include "main.h"

extern char drvTracks[_MAX_LFN + sizeof(strUSBupdateDIR) + 4];
extern char Tracks[MAXTRACKS][_MAX_LFN];

void PCM_MP3(APP_PLAYER *app);
void PCM_Wave(APP_PLAYER *app);
FRESULT scan_files (const TCHAR *path, uint8_t *numTracks);
void DecodeAudio(APP_PLAYER *app);

#endif /* INC_DECODE_H_ */
