/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _CONFIG_FILE_H
#define _CONFIG_FILE_H

#define DEF_VOL 6
#define MIN_VOL	0
#define MAX_VOL 10
#define BUT_FLASH_LED	false
#define SIM_OUTPUT	true
#define PLAYTIMESEC 0	//Play to end of track //30 seconds
#define ATTLEVEL	100
#define RESETVOLTIME	180

void LoadSettingsFile(FIL* fil, const char* file, CONFIG_INFO* config);

#endif /* _CONFIG_FILE_H */
