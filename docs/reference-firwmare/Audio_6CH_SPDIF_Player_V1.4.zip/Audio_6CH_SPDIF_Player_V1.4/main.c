
#include <string.h>
#include "main.h"
#include "board_conf.h"
#include "config_file.h"
#include "helper.h"
#include "decode.h"
#include "LEDs.h"
#include "spiflash.h"
#include "stm32f4_sdio_sd.h"
#include "DIT4096.h"
#include "prompt.h"

#if	USB_ENABLED
#include "usbh_usr.h"
#include "usbh_msc_core.h"
#include "usb_hcd_int.h"

USB_OTG_CORE_HANDLE USB_OTG_Core;
USBH_HOST USB_Host;
#endif

// Version_Num is in startup_stm32f4xx.h

__attribute__ ((section(".Eeprom"))) uint8_t eeprom_settings[] = {DEF_VOL, MIN_VOL, MAX_VOL, BUT_FLASH_LED, SIM_OUTPUT, PLAYTIMESEC, RESETVOLTIME, ATTLEVEL, ATTLEVEL, ATTLEVEL, ATTLEVEL, ATTLEVEL, ATTLEVEL};

//uint8_t ResetVolCounter = 0x00;
static __IO uint8_t SDInsertDelay = 0x00;

static APP_PLAYER App_Player;

void SPI2_IRQHandler(void)
{
	if(bbPLAY_WAVE_FLAG) PCM_Wave(&App_Player);
	else PCM_MP3(&App_Player);
}

void TIM3_IRQHandler(void)
{
	TIM3->SR = ~TIM_SR_UIF; // clear UIF bit rc_w0

	SetCOPLED(&App_Player);

}

void SDIO_IRQHandler(void)
{
	SD_ProcessIRQSrc();
}

void DMA2_Stream3_IRQHandler(void)
{
	SD_ProcessDMAIRQ();
}

void DMA2_Stream6_IRQHandler(void)
{
	SD_ProcessDMAIRQ();
}

#if	USB_ENABLED
void TIM2_IRQHandler(void)
{
	USB_OTG_BSP_TimerIRQ();
}

void OTG_FS_IRQHandler(void)
{
	USBH_OTG_ISR_Handler(&USB_OTG_Core);
}
#endif

void TIM1_BRK_TIM9_IRQHandler(void)
{
	TIM9->SR = ~TIM_SR_UIF; // clear UIF bit rc_w0

	bbSCAN_KEYS_FLAG = BB_SET_BIT;
}

void TIM1_UP_TIM10_IRQHandler(void)
{
	TIM10->SR = ~TIM_SR_UIF; // clear UIF bit rc_w0

	bbSET_LEDS_FLAG = BB_SET_BIT;
	if(SDInsertDelay) SDInsertDelay--;
}

void TIM1_TRG_COM_TIM11_IRQHandler(void)
{
	uint32_t i;
	static uint8_t SetLED = 0x00;

	TIM11->SR = ~TIM_SR_UIF; // clear UIF bit rc_w0

	for (i=0; i<_NUM_CH; i++)
	{
		if(App_Player.CH_info.PlayCounter[i]) App_Player.CH_info.PlayCounter[i]--;
	}

	if(App_Player.One_Second_Counters.ResetVolCounter) App_Player.One_Second_Counters.ResetVolCounter--;
	if(App_Player.One_Second_Counters.StopTimeSec)	App_Player.One_Second_Counters.StopTimeSec--;
	if(App_Player.One_Second_Counters.PromptEnterExitTimeSec) App_Player.One_Second_Counters.PromptEnterExitTimeSec--;
	if(App_Player.One_Second_Counters.PromptTimeSec) App_Player.One_Second_Counters.PromptTimeSec--;
	if(App_Player.One_Second_Counters.PauseTimeoutSec) App_Player.One_Second_Counters.PauseTimeoutSec--;
	if(App_Player.One_Second_Counters.KeepAliveCounter) App_Player.One_Second_Counters.KeepAliveCounter--;

	if(App_Player.Media_Copy_State == COPY_TO_NOR)
	{
		for (i=0; i<_NUM_CH; i++)
		{
			App_Player.CH_info.LEDGPIO[i]->BSRRH = App_Player.CH_info.LEDGPIOpin[i];	/* Turn Off LEDs */
		}
		if(SetLED >= _NUM_CH) SetLED = 0x00;
		App_Player.CH_info.LEDGPIO[SetLED]->BSRRL = App_Player.CH_info.LEDGPIOpin[SetLED];	/* Turn On LED */
		SetLED++;
	}
}

void ClearFlags(void)
{
	uint32_t i;

	*App_Player.Flags = BB_CLEAR_BIT;

	for(i=0; i<_NUM_CH; i++)
	{
		//App_Player.CH_info.MuteGPIO[i]->BSRRH = App_Player.CH_info.MuteGPIOpin[i];	/* Mute Output */
		App_Player.CH_info.PlayCounter[i] = 0x00;
		App_Player.CH_info.PlayState[i] = false;
	}
	App_Player.One_Second_Counters.ResetVolCounter = 0x00;
	App_Player.One_Second_Counters.StopTimeSec = 0x00;
	App_Player.One_Second_Counters.PromptEnterExitTimeSec = 0x00;
	App_Player.One_Second_Counters.PromptTimeSec = 0x00;
	App_Player.One_Second_Counters.PauseTimeoutSec = 0x00;
	App_Player.One_Second_Counters.KeepAliveCounter = KEEPALIVETIME;
}

#if	USB_ENABLED
void USB_Event(void)
{
	USB_App(&App_Player);
}
#endif

static void Init_CH_info(void)
{
	uint32_t i;

	App_Player.CH_info.KeyGPIO[0] = SW1_GPIO_Port;
	App_Player.CH_info.KeyGPIOpin[0] = SW1_Pin;
	App_Player.CH_info.LEDGPIO[0] = LED1_GPIO_Port;
	App_Player.CH_info.LEDGPIOpin[0] = LED1_Pin;

	App_Player.CH_info.KeyGPIO[1] = SW2_GPIO_Port;
	App_Player.CH_info.KeyGPIOpin[1] = SW2_Pin;
	App_Player.CH_info.LEDGPIO[1] = LED2_GPIO_Port;
	App_Player.CH_info.LEDGPIOpin[1] = LED2_Pin;

	App_Player.CH_info.KeyGPIO[2] = SW3_GPIO_Port;
	App_Player.CH_info.KeyGPIOpin[2] = SW3_Pin;
	App_Player.CH_info.LEDGPIO[2] = LED3_GPIO_Port;
	App_Player.CH_info.LEDGPIOpin[2] = LED3_Pin;

	App_Player.CH_info.KeyGPIO[3] = SW4_GPIO_Port;
	App_Player.CH_info.KeyGPIOpin[3] = SW4_Pin;
	App_Player.CH_info.LEDGPIO[3] = LED4_GPIO_Port;
	App_Player.CH_info.LEDGPIOpin[3] = LED4_Pin;

	App_Player.CH_info.KeyGPIO[4] = SW5_GPIO_Port;
	App_Player.CH_info.KeyGPIOpin[4] = SW5_Pin;
	App_Player.CH_info.LEDGPIO[4] = LED5_GPIO_Port;
	App_Player.CH_info.LEDGPIOpin[4] = LED5_Pin;

	App_Player.CH_info.KeyGPIO[5] = SW6_GPIO_Port;
	App_Player.CH_info.KeyGPIOpin[5] = SW6_Pin;
	App_Player.CH_info.LEDGPIO[5] = LED6_GPIO_Port;
	App_Player.CH_info.LEDGPIOpin[5] = LED6_Pin;


	for(i=0; i<_NUM_CH; i++)
	{
		//App_Player.CH_info.MuteGPIO[i]->BSRRH = App_Player.CH_info.MuteGPIOpin[i];	/* Mute Output */
		App_Player.CH_info.LEDGPIO[i]->BSRRL = App_Player.CH_info.LEDGPIOpin[i];	/* Turn On LEDs */
		App_Player.CH_info.PlayCounter[i] = 0x00;
		App_Player.CH_info.PlayState[i] = false;
	}
	LED_VOLUP_ON;
	LED_VOLDN_ON;
	NOR_SPI_CS_HIGH;
}

static void LoadSettingsFromFlash(void)
{
	memcpy(&App_Player.Config_info, &eeprom_settings, sizeof(CONFIG_INFO));

	App_Player.OutputVolumelevel = (App_Player.Config_info.DefaultVolume << 1);
}

void WriteDIT4096(uint8_t reg, uint8_t data)
{
	uint8_t a;

	a = 0xFF;
	for (; a != 0; a--);
	/* Wait for SPI1 Tx buffer empty */
	while (!(SPI1->SR & SPI_SR_TXE));
	/* Write in the DR register the data to be sent */
	DAC_MS_L;
	SPI1->DR = reg;
	/* Wait for SPI1 Tx completed */
	while (!(SPI1->SR & SPI_SR_RXNE));
	a = (uint8_t)SPI1->DR;
	SPI1->DR = reg;
	/* Wait for SPI1 Tx completed */
	while (!(SPI1->SR & SPI_SR_RXNE));
	a = (uint8_t)SPI1->DR;
	SPI1->DR = data;
	/* Wait for SPI1 Tx completed */
	while (!(SPI1->SR & SPI_SR_RXNE));
	a = (uint8_t)SPI1->DR;
	DAC_MS_H;
}

static void AppStart(void)
{
	while(1)
	{
		IWDG->KR = 0xAAAA; //IWDG_ReloadCounter();

#if	USB_ENABLED
		/* Host Task handler */
		USBH_Process(&USB_OTG_Core, &USB_Host);
		if(USB_Host.EnumState == ENUM_DEV_CONFIGURED) bbUSB_CONNECT_STATE = BB_SET_BIT;	//USB file transfer is handled in usbh_usr.c, USBH_USR_MSC_Application(void)
		else if(USB_Host.EnumState == ENUM_IDLE) bbUSB_CONNECT_STATE = BB_CLEAR_BIT;
#endif

		if(!bbUSB_CONNECT_STATE)
		{
			App_Player.Media_Copy_State = MOUNT_USB_DRIVE;
			if(CARD_DETECT)	/* Card not detected */
			{
				if(SD_PWR_STATE)
				{
					SD_off();
					ClearFlags();
					App_Player.Decode_State = IDLE_STATE;
				}
				bbSD_CONNECT_STATE = BB_CLEAR_BIT;
				bbSD_INITIALIZE_STATE = BB_CLEAR_BIT;
			}
			else
			{
				bbSD_CONNECT_STATE = BB_SET_BIT;
				bbNOR_INITIALIZE_STATE = BB_CLEAR_BIT;
			}

			if(!bbSD_CONNECT_STATE)
			{
				if(bbNOR_CONNECT_STATE)
				{
					if(!bbNOR_INITIALIZE_STATE)
					{
						ClearFlags();
						bbNOR_INITIALIZE_STATE = BB_SET_BIT;
						f_close(App_Player.pFIL);
						f_mount(NULL, App_Player.pDrive, 0);
						App_Player.pFATFS = &App_Player.fs4K;	//Change to NOR filesystem
						App_Player.pFIL = &App_Player.fil4K;
						App_Player.pDrive = strNORdrive;
						App_Player.Decode_State = MOUNT_DRIVE;
					}
				}
			}
			else
			{
				if(!bbSD_INITIALIZE_STATE)
				{
					SD_PWR_ON;
					ClearFlags();
					SDInsertDelay = 4;
					while(SDInsertDelay) { }
					SD_on();
					bbSD_INITIALIZE_STATE = BB_SET_BIT;
					f_close(App_Player.pFIL);
					f_mount(NULL, App_Player.pDrive, 0);
					App_Player.pFATFS = (FATFS*)&App_Player.fs512;	//Change to SD filesystem
					App_Player.pFIL = (FIL*)&App_Player.fil512;
					App_Player.pDrive = strSDdrive;
					App_Player.Decode_State = MOUNT_DRIVE;
				}
			}
			DecodeAudio(&App_Player);
		}
	}
}

static void HardwareInit(void)
{

	DBGMCU_APB2PeriphConfig(DBGMCU_TIM9_STOP, ENABLE);
	DBGMCU_APB2PeriphConfig(DBGMCU_TIM10_STOP, ENABLE);
	DBGMCU_APB1PeriphConfig(DBGMCU_IWDG_STOP, ENABLE);

	App_Player.Flags = ((__IO APP_FLAGS*)(SRAM1_BASE));
	App_Player.Media_State = ((__IO MEDIA_STATE*)(SRAM1_BASE + 0x00000004));
	*App_Player.Media_State = BB_CLEAR_BIT;

	RCC_Configuration();
	GPIO_Configuration();
	Init_CH_info();
	SD_off();
	I2S_Configuration(44100);
	SPI_Configuration();
	SDIO_Configuration();
	TIM3_Configuration();
	TIM9_Configuration();
	TIM10_Configuration();
	TIM11_Configuration();
	LoadSettingsFromFlash();

	App_Player.Decode_State = IDLE_STATE;
	App_Player.Prompt_State = ENTER_STATE;

	RST_OFF;

#if	USB_ENABLED
	/* Init Host Library */
	USBH_Init(&USB_OTG_Core, USB_OTG_FS_CORE_ID, &USB_Host, &USBH_MSC_cb, &USR_cb);
#endif

	bbSD_CONNECT_STATE = BB_SET_BIT;

	App_Player.pFATFS = (FATFS*)&App_Player.fs512;	//Assign pointers to SD filesystem
	App_Player.pFIL = (FIL*)&App_Player.fil512;
	App_Player.pDrive = strSDdrive;

#if	NOR_ENABLED
	uint32_t DeviceID = SPIflashReadID();
	if((DeviceID > 0ul) && (DeviceID < 0xFFFFFFFF))
	{
		FRESULT res = f_mount(&App_Player.fs4K, strNORdrive, 1);
		if(res == FR_OK) bbNOR_CONNECT_STATE = BB_SET_BIT;
		if(res == FR_NO_FILESYSTEM)
		{
			res = f_mkfs(strNORdrive, 1, 0);
			if(res == FR_OK) bbNOR_CONNECT_STATE = BB_SET_BIT;
		}
	}
#endif

	WriteDIT4096(TRANS_CONTROL_REG, 0x01);
	WriteDIT4096(ASP_CONTROL_REG, 0xA0);	//Phillips I2S
	WriteDIT4096(PWR_CLK_CONTROL_REG, 2);

	WDG_Configuration();
}

int main(void)
{
	HardwareInit();
	AppStart();

	/* Go into an infinite loop. Should never get here */
	while (1)
	{
	}
}

