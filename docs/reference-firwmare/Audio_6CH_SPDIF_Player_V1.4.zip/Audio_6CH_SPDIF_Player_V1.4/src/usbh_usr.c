/**
  ******************************************************************************
  * @file    FW_upgrade/src/usbh_usr.c
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    28-October-2011
  * @brief   This file includes the usb host user callbacks
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "main.h"
#include "usbh_usr.h"
#include "decode.h"
#include "mp3dec.h"

/** @addtogroup STM32F4-Discovery_FW_Upgrade
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private defines -----------------------------------------------------------*/
/* Private macros ------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/*  Points to the DEVICE_PROP structure of current device */
/*  The purpose of this register is to speed up the execution */

USBH_Usr_cb_TypeDef USR_cb =
{
  USBH_USR_Init,
  USBH_USR_DeInit,
  USBH_USR_DeviceAttached,
  USBH_USR_ResetDevice,
  USBH_USR_DeviceDisconnected,
  NotUsed_Handler,	//USBH_USR_OverCurrentDetected,
  USBH_USR_DeviceSpeedDetected,
  USBH_USR_Device_DescAvailable,
  NotUsed_Handler,	//USBH_USR_DeviceAddressAssigned,
  USBH_USR_Configuration_DescAvailable,
  NotUsed_Handler2,	//USBH_USR_Manufacturer_String,
  NotUsed_Handler2,	//USBH_USR_Product_String,
  NotUsed_Handler2,	//USBH_USR_SerialNum_String,
  USBH_USR_EnumerationDone,
  //USBH_USR_UserInput,
  USBH_USR_MSC_Application,
  USBH_USR_DeviceNotSupported,
  USBH_USR_UnrecoveredError
};

void NotUsed_Handler(void){ }
void NotUsed_Handler2(void *i){ }

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

static uint8_t FileCopyToNOR(APP_PLAYER* app, const TCHAR* src, const TCHAR* dest)
{
	UINT br, bw;
	FRESULT res;

	res = f_open(app->pFIL, src, FA_OPEN_EXISTING | FA_READ);
	if(res != FR_OK) return 0x01;
	res = f_open(&app->fil4K, dest, FA_WRITE | FA_CREATE_ALWAYS);
	if(res != FR_OK) return 0x01;
	for(;;)
	{
		IWDG->KR = 0xAAAA; //IWDG_ReloadCounter();
		res = f_read(app->pFIL, DecoderAudioBuffer.WAVBuffer8.WAVBuffer8_1, 4096, &br);
		if (br == 0) break; //error or eof/
		res = f_write(&app->fil4K, DecoderAudioBuffer.WAVBuffer8.WAVBuffer8_1, br, &bw);
		if (bw < br) break; //error or disk full
	}
	f_close(app->pFIL);
	f_close(&app->fil4K);
	if(res != FR_OK) return 0x01;

	return 0x00;
}

void USB_App(APP_PLAYER* app)
{
	uint8_t i;
	FRESULT res;
	static uint8_t numOfTracks = 0x00;
	static char drvTracksDST[_MAX_LFN + sizeof(strUSBupdateDIR) + 4];

	switch(app->Media_Copy_State)
	{
		case DECODE_USB:
		{
			DecodeAudio(app);
			break;
		}
		case MOUNT_USB_DRIVE:
		{
			ClearFlags();
			bbSD_INITIALIZE_STATE = BB_CLEAR_BIT;
			bbNOR_INITIALIZE_STATE = BB_CLEAR_BIT;
			app->pFATFS = (FATFS*)&app->fs512;	//Change to SD filesystem
			app->pFIL = (FIL*)&app->fil512;
			app->pDrive = strSDdrive;
			f_close(app->pFIL);
			f_mount(NULL, app->pDrive, 0);
			app->pDrive = strUSBdrive;
			res = f_mount(app->pFATFS, app->pDrive, 1);
			app->Media_Copy_State = FIND_TRACKS;
			if(res != FR_OK)
			{
				app->Media_Copy_State = ERROR_STATE;
				break;
			}
			if(!bbNOR_CONNECT_STATE)
			{
				f_mount(NULL, app->pDrive, 0);
				app->Decode_State = MOUNT_DRIVE;
				app->Media_Copy_State = DECODE_USB;
				break;
			}
			break;
		}
		case FIND_TRACKS:
		{
			res = scan_files(strUSBupdateDIR, &numOfTracks);
			app->Media_Copy_State = MOUNT_NOR_DRIVE;
			if(res != FR_OK) app->Media_Copy_State = ERROR_STATE;
			if(res == FR_NO_PATH)
			{
				f_mount(NULL, app->pDrive, 0);
				app->Decode_State = MOUNT_DRIVE;
				app->Media_Copy_State = DECODE_USB;
				break;
			}
			break;
		}
		case MOUNT_NOR_DRIVE:
		{
			f_close(&app->fil4K);
			f_mount(NULL, strNORdrive, 0);
			res = f_mount(&app->fs4K, strNORdrive, 1);
			app->Media_Copy_State = FORMAT_NOR;
			if(res != FR_OK) app->Media_Copy_State = ERROR_STATE;
			break;
		}
		case FORMAT_NOR:
		{
			res = f_mkfs(strNORdrive, 1, 0);
			app->Media_Copy_State = COPY_TO_NOR;
			if(res != FR_OK) app->Media_Copy_State = ERROR_STATE;
			break;
		}
		case COPY_TO_NOR:
		{
			for(i=0; i<numOfTracks; i++)
			{
				strcpy(drvTracks, strUSBupdateDIR);
				strcat(drvTracks, "/");
				strcat(drvTracks, Tracks[i]);
				strcpy(drvTracksDST, strNORdrive);
				strcat(drvTracksDST, Tracks[i]);

				if(FileCopyToNOR(app, drvTracks, drvTracksDST))
				{
					app->Media_Copy_State = ERROR_STATE;
					break;
				}
			}
			strcpy(drvTracks, strUSBupdateDIR);	//Copy Config file
			strcat(drvTracks, "/");
			strcat(drvTracks, strConfigFile);
			strcpy(drvTracksDST, strNORdrive);
			strcat(drvTracksDST, strConfigFile);

			i = FileCopyToNOR(app, drvTracks, drvTracksDST);
			//{
			//	Media_Copy_State = ERROR_STATE;
			//	break;
			//}
			app->Media_Copy_State = DONE_STATE;
			break;
		}
		case DONE_STATE:
		case ERROR_STATE:
		{
			break;
		}
	}
}

void USBH_USR_Init(void)
{
  
}

void USBH_USR_DeInit(void)
{

}

void USBH_USR_DeviceAttached(void)
{
  
}

void USBH_USR_ResetDevice(void)
{

}

void USBH_USR_DeviceDisconnected (void)
{

}

void USBH_USR_DeviceSpeedDetected(uint8_t DeviceSpeed)
{
	if ((DeviceSpeed != HPRT0_PRTSPD_FULL_SPEED)&&(DeviceSpeed != HPRT0_PRTSPD_LOW_SPEED))
	{

	}
}

void USBH_USR_Device_DescAvailable(void *DeviceDesc)
{

}

void USBH_USR_Configuration_DescAvailable(USBH_CfgDesc_TypeDef * cfgDesc, USBH_InterfaceDesc_TypeDef *itfDesc, USBH_EpDesc_TypeDef *epDesc)
{

}

void USBH_USR_EnumerationDone(void)
{

} 


/**
  * @brief  USBH_USR_UserInput
  *         User Action for application state entry
  * @param  None
  * @retval USBH_USR_Status : User response for key button
  */
//USBH_USR_Status USBH_USR_UserInput(void)
//{
  /* callback for Key botton: set by software in this case */
//  return USBH_USR_RESP_OK;
//}

/**
  * @brief  USBH_USR_MSC_Application
  *         Demo application for IAP thru USB mass storage
  * @param  None
  * @retval Staus
  */
int USBH_USR_MSC_Application(void)
{
	USB_Event();
	return(0);
}

void USBH_USR_DeviceNotSupported(void)
{

}

void USBH_USR_UnrecoveredError (void)
{

}
