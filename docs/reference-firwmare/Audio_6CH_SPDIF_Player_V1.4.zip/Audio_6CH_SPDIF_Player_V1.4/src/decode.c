
#include <string.h>
#include "decode.h"
#include "Buttons.h"
#include "LEDs.h"
#include "config_file.h"
#include "board_conf.h"
#include "mp3dec.h"
#include "wavparser.h"
#include "helper.h"
#include "prompt.h"
#include "20khz.h"
#include "DIT4096.h"

#define MAXTRACKS	30

uint8_t KeepAlivemode = 0x00;
static MP3FrameInfo frameInfo;
static WAV_FMT WaveFormat;

static uint16_t buffercount = 0x0000;

static INT KeepAlivebytesleft;
static uint8_t *KeepAlivePtr;

char Tracks[MAXTRACKS][_MAX_LFN];
char drvTracks[_MAX_LFN + sizeof(strUSBupdateDIR) + 4];

//float Volvalue[21] = {0.0071, 0.0071, 0.0086, 0.01, 0.0122, 0.0158, 0.0181, 0.0224, 0.0274, 0.0316, 0.0387, 0.05, 0.0574, 0.0707, 0.0866, 0.1, 0.1224, 0.1581, 0.1816, 0.2236, 0.2738};
float Volvalue[21] = {0.0071, 0.0071, 0.0089, 0.0107, 0.0134, 0.0179, 0.0211, 0.0268, 0.0338, 0.0401, 0.0503, 0.0667, 0.0786, 0.0989, 0.1242, 0.147, 0.1836, 0.2426, 0.2851, 0.3577, 0.4476};
/**
 * Clip a signed integer value into the -32768,32767 range.
 * @param a value to clip
 * @return clipped value
 */
//static int16_t av_clip_int16_c(int16_t a, float att)
static int16_t av_clip_int16_c(int16_t a, APP_PLAYER *app)
{
	int vol = (int)(255.0 * Volvalue[app->OutputVolumelevel] * app->OutputAttLevel);
	int x = (a * vol) >> 8;

    if ((x+0x8000U) & ~0xFFFF) return (x>>31) ^ 0x7FFF;
    else return x;
}

void PCM_Wave(APP_PLAYER *app)
{
	int16_t a;

	if(WaveFormat.NumChannels == 2)
	{
		if(WaveFormat.BitsPerSample == 8)
		{
			char z;

			if(!bbTOGGLE_BUFFER_FLAG)
			{
				if(bbBUFFER_FULL_FLAG)
				{
					z = DecoderAudioBuffer.WAVBuffer8.WAVBuffer8_1[buffercount] - 0x80;
					SPI2->DR = (uint16_t)av_clip_int16_c((int16_t)(z << 8), app);
					buffercount ++;
					if(buffercount >= WAVBUFFER8_SIZE)
					{
						buffercount = 0;
						bbTOGGLE_BUFFER_FLAG = BB_SET_BIT;
						bbBUFFER_FULL_FLAG = BB_CLEAR_BIT;
					}
				}
				else SPI2->DR = 0x0000;
			}
			else
			{
				if(bbBUFFER2_FULL_FLAG)
				{
					z = DecoderAudioBuffer.WAVBuffer8.WAVBuffer8_2[buffercount] - 0x80;
					SPI2->DR = (uint16_t)av_clip_int16_c((int16_t)(z << 8), app);
					buffercount ++;
					if(buffercount >= WAVBUFFER8_SIZE)
					{
						buffercount = 0;
						bbBUFFER2_FULL_FLAG = BB_CLEAR_BIT;
						bbTOGGLE_BUFFER_FLAG = BB_CLEAR_BIT;
					}
				}
				else SPI2->DR = 0x0000;
			}
		}
		else if(WaveFormat.BitsPerSample == 16)
		{
			if(!bbTOGGLE_BUFFER_FLAG)
			{
				if(bbBUFFER_FULL_FLAG)
				{
					SPI2->DR = (uint16_t)av_clip_int16_c(DecoderAudioBuffer.WAVBuffer16.WAVBuffer16_1[buffercount], app);
					buffercount ++;
					if(buffercount >= WAVBUFFER16_SIZE)
					{
						buffercount = 0;
						bbTOGGLE_BUFFER_FLAG = BB_SET_BIT;
						bbBUFFER_FULL_FLAG = BB_CLEAR_BIT;
					}
				}
				else SPI2->DR = 0x0000;
			}
			else
			{
				if(bbBUFFER2_FULL_FLAG)
				{
					SPI2->DR = (uint16_t)av_clip_int16_c(DecoderAudioBuffer.WAVBuffer16.WAVBuffer16_2[buffercount], app);
					buffercount ++;
					if(buffercount >= WAVBUFFER16_SIZE)
					{
						buffercount = 0;
						bbBUFFER2_FULL_FLAG = BB_CLEAR_BIT;
						bbTOGGLE_BUFFER_FLAG = BB_CLEAR_BIT;
					}
				}
				else SPI2->DR = 0x0000;
			}
		}
		else if(WaveFormat.BitsPerSample == 24)
		{
			if(!bbTOGGLE_BUFFER_FLAG)
			{
				if(bbBUFFER_FULL_FLAG)
				{
					a = ((DecoderAudioBuffer.WAVBuffer24.WAVBuffer24_1[buffercount][2] << 8) | (DecoderAudioBuffer.WAVBuffer24.WAVBuffer24_1[buffercount][1]));
					SPI2->DR = (uint16_t)av_clip_int16_c(a, app);
					buffercount ++;
					if(buffercount >= WAVBUFFER24_SIZE)
					{
						buffercount = 0;
						bbTOGGLE_BUFFER_FLAG = BB_SET_BIT;
						bbBUFFER_FULL_FLAG = BB_CLEAR_BIT;
					}
				}
				else SPI2->DR = 0x0000;
			}
			else
			{
				if(bbBUFFER2_FULL_FLAG)
				{
					a = ((DecoderAudioBuffer.WAVBuffer24.WAVBuffer24_2[buffercount][2] << 8) | (DecoderAudioBuffer.WAVBuffer24.WAVBuffer24_2[buffercount][1]));
					SPI2->DR = (uint16_t)av_clip_int16_c(a, app);
					buffercount ++;
					if(buffercount >= WAVBUFFER24_SIZE)
					{
						buffercount = 0;
						bbBUFFER2_FULL_FLAG = BB_CLEAR_BIT;
						bbTOGGLE_BUFFER_FLAG = BB_CLEAR_BIT;
					}
				}
				else SPI2->DR = 0x0000;
			}
		}
		else SPI2->DR = 0x0000;
	}
	else SPI2->DR = 0x0000;
}

void PCM_MP3(APP_PLAYER *app)
{
	if(frameInfo.nChans == 2)
	{
		if(!bbTOGGLE_BUFFER_FLAG)
		{
			if(bbBUFFER_FULL_FLAG)
			{
				SPI2->DR = (uint16_t)av_clip_int16_c(DecoderAudioBuffer.MP3Buffer.PCMbuffer1[buffercount], app);
				buffercount ++;
				if(buffercount >= frameInfo.outputSamps)
				{
					buffercount = 0;
					bbTOGGLE_BUFFER_FLAG = BB_SET_BIT;
					bbBUFFER_FULL_FLAG = BB_CLEAR_BIT;
				}
			}
			else SPI2->DR = 0x0000;
		}
		else
		{
			if(bbBUFFER2_FULL_FLAG)
			{
				SPI2->DR = (uint16_t)av_clip_int16_c(DecoderAudioBuffer.MP3Buffer.PCMbuffer2[buffercount], app);
				buffercount ++;
				if(buffercount >= frameInfo.outputSamps)
				{
					buffercount = 0;
					bbBUFFER2_FULL_FLAG = BB_CLEAR_BIT;
					bbTOGGLE_BUFFER_FLAG = BB_CLEAR_BIT;
				}
			}
			else SPI2->DR = 0x0000;
		}
	}
	else
	{
		if(!bbTOGGLE_BUFFER_FLAG)
		{
			if(bbBUFFER_FULL_FLAG)
			{
				SPI2->DR = (uint16_t)av_clip_int16_c(DecoderAudioBuffer.MP3Buffer.PCMbuffer1[buffercount], app);
				if(bbMONO_TOGGLE_FLAG)
				{
					bbMONO_TOGGLE_FLAG = BB_CLEAR_BIT;
					buffercount ++;
				}
				else bbMONO_TOGGLE_FLAG = BB_SET_BIT;
				if(buffercount >= frameInfo.outputSamps)
				{
					buffercount = 0;
					bbTOGGLE_BUFFER_FLAG = BB_SET_BIT;
					bbBUFFER_FULL_FLAG = BB_CLEAR_BIT;
				}
			}
			else SPI2->DR = 0x0000;
		}
		else
		{
			if(bbBUFFER2_FULL_FLAG)
			{
				SPI2->DR = (uint16_t)av_clip_int16_c(DecoderAudioBuffer.MP3Buffer.PCMbuffer2[buffercount], app);
				if(bbMONO_TOGGLE_FLAG)
				{
					bbMONO_TOGGLE_FLAG = BB_CLEAR_BIT;
					buffercount ++;
				}
				else bbMONO_TOGGLE_FLAG = BB_SET_BIT;
				if(buffercount >= frameInfo.outputSamps)
				{
					buffercount = 0;
					bbBUFFER2_FULL_FLAG = BB_CLEAR_BIT;
					bbTOGGLE_BUFFER_FLAG = BB_CLEAR_BIT;
				}
			}
			else SPI2->DR = 0x0000;
		}
	}
}

static void WriteDITChannelStatusBuffer(uint32_t samprate)
{
	uint8_t i;

	WriteDIT4096(BUF_TRANS_REG, 0x01);	//DISABLE UA TO TA BUFFER TRANSFER Set BTD = 1 in Control Register 07H

	/* UPDATE THE CS DATA, Write Channel Status Data to the UA Buffer http://www.minidisc.org/spdif_c_channel.html */
	WriteDIT4096(0x08, 0x20);
	WriteDIT4096(0x09, 0x20);
	WriteDIT4096(0x0A, 0x00);
	WriteDIT4096(0x0B, 0x00);
	WriteDIT4096(0x0C, 0x00);
	WriteDIT4096(0x0D, 0x00);
	if(samprate == 48000ul) i = 0x40;
	else if(samprate == 32000ul) i = 0xC0;
	else i = 0x00;
	WriteDIT4096(0x0E, i);
	WriteDIT4096(0x0F, i);
	WriteDIT4096(0x10, 0x40);
	WriteDIT4096(0x11, 0x40);
	for(i=0x12; i<0x38; i++)
	{
		WriteDIT4096(i, 0x00);
	}


	WriteDIT4096(BUF_TRANS_REG, 0x00);	//ENABLE UA TO TA BUFFER TRANSFER Set BTD = 0 in Control Register 07H
}

FRESULT scan_files (const TCHAR *path, uint8_t *numTracks)
{
    FRESULT res;
    DIR dir;
    uint8_t i;
    uint8_t j;
    uint8_t temp = 0x00;
    static FILINFO fno;
    char TempA[_MAX_LFN];
    char TrackName[_MAX_LFN];

    fno.lfname = TempA;
    fno.lfsize = _MAX_LFN;

    memset(Tracks, 0, MAXTRACKS * _MAX_LFN);
    res = f_opendir(&dir, path);                       /* Open the directory */
    if (res == FR_OK) {
        for (;;) {
            res = f_readdir(&dir, &fno);                   /* Read a directory item */
            if (res != FR_OK || fno.fname[0] == 0) break;  /* Break on error or end of dir */
            memset(TrackName, 0, _MAX_LFN);
            memmove(TrackName, fno.lfname, _MAX_LFN);
            StrLower(TrackName);
			if((strstr(TrackName, ".wav")) || (strstr(TrackName, ".mp3")))
			{
				if(temp < MAXTRACKS)
				{
					strcpy(Tracks[temp], fno.lfname);
					temp++;
				}
			}
			else
			{
				memset(TrackName, 0, _MAX_LFN);
				memmove(TrackName, fno.fname, 13);
				StrLower(TrackName);
				if((strstr(TrackName, ".wav")) || (strstr(TrackName, ".mp3")))
				{
					if(temp < MAXTRACKS)
					{
						strcpy(Tracks[temp], fno.fname);
						temp++;
					}
				}
			}
        }
        f_closedir(&dir);

        *numTracks = temp;
        if(!temp) return FR_NO_FILE;

        for (i = 1; i < temp; i++)	//sort tracks in alphabetical order
        {
		  for (j = 1; j < temp; j++)
		  {
			 if (strcmp(Tracks[j - 1], Tracks[j]) > 0)
			 {
				strcpy(TempA, Tracks[j - 1]);
				strcpy(Tracks[j - 1], Tracks[j]);
				strcpy(Tracks[j], TempA);
			 }
		  }
	   }
    }
    return res;
}

void KeepAliveReset(APP_PLAYER *app)
{
	KeepAlivemode = 0x00;
	KeepAlivebytesleft = sizeof _20KHZ;
	KeepAlivePtr = (uint8_t*)_20KHZ;
	app->One_Second_Counters.KeepAliveCounter = KEEPALIVETIME;
}

static int FillReadBuffer(FIL *pFIL, unsigned char *readBuf, unsigned char *readPtr, int bytesLeft)
{
    UINT nRead;
    FRESULT res;

    /* move last, small chunk from end of buffer to start, then fill with new data */
    memmove(readBuf, readPtr, bytesLeft);
    res = f_read(pFIL, readBuf + bytesLeft, MAINBUF_SIZE - bytesLeft, &nRead);     /* Read a chunk of src file */
    if (res || nRead == 0) return 0;
    /* zero-pad to avoid finding false sync word after last frame (from old data in readBuf) */
    if (nRead < MAINBUF_SIZE - bytesLeft)
        memset(readBuf + bytesLeft + nRead, 0, MAINBUF_SIZE - bytesLeft - nRead);

    return nRead;
}

static void SelectOutput(uint8_t output)
{
	if (!output) //Opt1-y6
	{
		GPIO_SetBits(SW_E_GPIO_Port, SW_S1_Pin | SW_S2_Pin);
		GPIO_ResetBits(SW_E_GPIO_Port, SW_E_Pin | SW_S0_Pin);
	}
	else if (output == 1) //Opt2-y4
	{
		GPIO_SetBits(SW_E_GPIO_Port, SW_S2_Pin);
		GPIO_ResetBits(SW_E_GPIO_Port, SW_E_Pin | SW_S0_Pin | SW_S1_Pin);
	}
	else if (output == 2) //Opt3-y7
	{
		GPIO_SetBits(SW_E_GPIO_Port, SW_S0_Pin | SW_S1_Pin | SW_S2_Pin);
		GPIO_ResetBits(SW_E_GPIO_Port, SW_E_Pin);
	}
	else if (output == 3) //Opt4-y2
	{
		GPIO_SetBits(SW_E_GPIO_Port, SW_S1_Pin);
		GPIO_ResetBits(SW_E_GPIO_Port, SW_E_Pin | SW_S0_Pin | SW_S2_Pin);
	}
	else if (output == 4) //Opt5-y1
	{
		GPIO_SetBits(SW_E_GPIO_Port, SW_S0_Pin);
		GPIO_ResetBits(SW_E_GPIO_Port, SW_E_Pin | SW_S1_Pin | SW_S2_Pin);
	}
	else if (output == 5) //Opt6-y0
	{
		GPIO_ResetBits(SW_E_GPIO_Port, SW_E_Pin | SW_S0_Pin | SW_S1_Pin | SW_S2_Pin);
	}
}

static uint8_t ContinueDecode(APP_PLAYER *app)
{
	uint8_t i;

	for(i=0; i<_NUM_CH; i++)
	{
		if(app->CH_info.PlayState[i])
		{
			//app->CH_info.MuteGPIO[i]->BSRRL = app->CH_info.MuteGPIOpin[i];	/* Turn On Output */
			SelectOutput(i); /* Turn On Output */
			app->One_Second_Counters.KeepAliveCounter = KEEPALIVETIME;
			return 0x01;	/* Decode the frame */
		}
	}
	SW_E_HIGH;	/* Mute Output */
	return 0x00;
}

static void EndDecode(APP_PLAYER *app)
{
	uint8_t i;

	f_close(app->pFIL);
	if(!(app->Config_info.PlayTimeSec))
	{
		for(i=0; i<_NUM_CH; i++)
		{
			app->CH_info.PlayState[i] = false;
			//app->CH_info.MuteGPIO[i]->BSRRH = app->CH_info.MuteGPIOpin[i];	/* Turn Off Output */
		}
		KeepAliveReset(app);
	}
	app->Decode_State = PLAY_NEXT_FILE;
}

void DecodeAudio(APP_PLAYER *app)
{

#define SZ_TBL	10
	uint8_t i;
	//uint8_t i2cData = 0xFF;
	FRESULT res;
	int err;
	static DWORD clmt[SZ_TBL];	/* Cluster link map table buffer */
	static uint8_t TrackCounter = 0x00;
	static uint8_t TracksOnCard = 0x00;
	static uint8_t *readPtr;
	static uint8_t buffer[MAINBUF_SIZE];   /* file copy buffer */
	static HMP3Decoder hMP3Decoder;
	static INT offset, nRead, BytesRemaning;

	if(bbSCAN_KEYS_FLAG)
	{
		bbSCAN_KEYS_FLAG = BB_CLEAR_BIT;
		if(app->Decode_State > OPEN_TRACK)
		{
			if(!bbPROMPT_FLAG)
			{
				if(!app->One_Second_Counters.PromptEnterExitTimeSec)
				{
					TIM10->PSC = 160;	//330; Set the Prescaler value for LED fast flash
					bbPROMPT_FLAG = BB_SET_BIT;
					app->Prompt_State = ENTER_STATE;
				}
				//app->ExpBoardKeys.Val = i2cData;
				ScanButtons(app);
			}
			else PromptScanButtons(app);
		}
	}

	if(bbSET_LEDS_FLAG)
	{
		bbSET_LEDS_FLAG = BB_CLEAR_BIT;

		if(!bbPROMPT_FLAG)
		{
			bbTOGGLE_LED_FLAG = SetButtonLEDs(app, bbTOGGLE_LED_FLAG);

			if(app->Config_info.PlayTimeSec)
			{
				for(i=0; i<_NUM_CH; i++)
				{
					if(!(app->CH_info.PlayCounter[i])) app->CH_info.PlayState[i] = false;
				}
			}
		}
		else PromptSetButtonLEDs(app);
	}

	if((app->Decode_State == PLAYBACK_PAUSE) && (!(app->One_Second_Counters.PauseTimeoutSec))) app->Decode_State = PLAYBACK_STOP;

	switch(app->Decode_State)
	{
		case IDLE_STATE:
		{
			while (1) {	} //ERROR! WDT Reboot
			break;
		}
		case MOUNT_DRIVE:
		{
			res = f_mount(app->pFATFS, app->pDrive, 1);
			if(res == FR_OK) app->Decode_State = OPEN_CONFIG;
			TrackCounter = MAXTRACKS - 1;
			break;
		}
		case OPEN_CONFIG:
		{
			strcpy(drvTracks, app->pDrive);
			strcat(drvTracks, strConfigFile);
			LoadSettingsFile(app->pFIL, drvTracks, &app->Config_info);
			app->OutputVolumelevel = (app->Config_info.DefaultVolume << 1);
			app->Decode_State = OPEN_TRACK;
			break;
		}
		case OPEN_TRACK:
		{
			if(scan_files(app->pDrive, &TracksOnCard)) app->Decode_State = IDLE_STATE;
			else
			{
				KeepAliveReset(app);
				app->Decode_State = PLAYBACK_STOP;
			}
			app->One_Second_Counters.PromptEnterExitTimeSec = 10;
			break;
		}
		case OPEN_FILE:
		{
			bbBUFFER_FULL_FLAG = BB_CLEAR_BIT;
			bbBUFFER2_FULL_FLAG = BB_CLEAR_BIT;
			bbTOGGLE_BUFFER_FLAG = BB_CLEAR_BIT;
			buffercount = 0;
			if(!bbPROMPT_FLAG)
			{
				strcpy(drvTracks, app->pDrive);
				strcat(drvTracks, Tracks[TrackCounter]);
			}
			res = f_open(app->pFIL, drvTracks, FA_OPEN_EXISTING | FA_READ);
			if(bbPROMPT_FLAG)
			{
				if(res)
				{
					f_close(app->pFIL);
					app->Prompt_State = EXIT_STATE;
					app->Decode_State = PLAYBACK_STOP;
					break;
				}
			}
			if((res == FR_NO_FILE) || (res == FR_INVALID_NAME))
			{
				f_close(app->pFIL);
				app->Decode_State = PLAY_NEXT_FILE;
				break;
			}
			if(res) app->Decode_State = IDLE_STATE;
			else
			{
				BytesRemaning = 0;
				nRead = 0;
				app->Decode_State = READ_WAV_HEADER;
			}
			break;
		}
		case READ_WAV_HEADER:
		{
			app->pFIL->cltbl = clmt;                      /* Enable fast seek feature (cltbl != NULL) */
			clmt[0] = SZ_TBL;                      /* Set table size */
			res = f_lseek(app->pFIL, CREATE_LINKMAP);     /* Create CLMT */

			if(parse_wave_header(app->pFIL, &WaveFormat))
			{
				res = f_lseek(app->pFIL, 0);
				app->Decode_State = FRAME_SYNC_FIND;	//Maybe MP3 file?
				break;
			}
			I2S_Configuration(WaveFormat.SampleRate);
			WriteDITChannelStatusBuffer(WaveFormat.SampleRate);
			bbPLAY_WAVE_FLAG = BB_SET_BIT;
			app->Decode_State = WAV_DECODE;
			break;
		}
		case FRAME_SYNC_FIND:
		{
			/* Read the mp3 file. Fill the first buffer of
			 * data from the input file. */
			hMP3Decoder = MP3InitDecoder();
			if(!KeepAlivemode)
			{
				res = f_read(app->pFIL, buffer, sizeof buffer, (UINT*)&BytesRemaning);     /* Read a chunk of src file */
				if (res)
				{
					app->Decode_State = IDLE_STATE;
					break;
				}
				if (!BytesRemaning)
				{
					f_close(app->pFIL);
					app->Decode_State = PLAY_NEXT_FILE;
					break;
				}

				/* find start of first MP3 frame */
				readPtr = buffer;
				offset = MP3FindSyncWord(readPtr, BytesRemaning);

				if (offset < 0)
				{
					/* This means this frame does not contain
					 * the frame sync. Get another frame. */

					app->Decode_State = FRAME_SYNC_FIND;
					break;
				}

				/* Update the read pointer and number of bytes
				 * left in the current frame. */

				readPtr += offset;
				BytesRemaning -= offset;

				/* Determine the audio format from the first frame header. */
				offset = MP3GetNextFrameInfo(hMP3Decoder, &frameInfo, readPtr);
				if (offset < 0)
				{
					/* This means this frame does not contain
					 * the frame sync. Get another frame. */

					app->Decode_State = FRAME_SYNC_FIND;
					break;
				}
			}
			else
			{
				offset = MP3FindSyncWord(KeepAlivePtr, KeepAlivebytesleft);
				if (offset < 0)
				{
					/* This means this frame does not contain
					 * the frame sync. Get another frame. */

					app->Decode_State = FRAME_SYNC_FIND;
					break;
				}
				/* Update the read pointer and number of bytes
									 * left in the current frame. */

				KeepAlivePtr += offset;
				KeepAlivebytesleft -= offset;

				/* Determine the audio format from the first frame header. */
				offset = MP3GetNextFrameInfo(hMP3Decoder, &frameInfo, KeepAlivePtr);
			}
			I2S_Configuration(frameInfo.samprate);
			WriteDITChannelStatusBuffer(frameInfo.samprate);
			bbPLAY_WAVE_FLAG = BB_CLEAR_BIT;
			/* Start reading the MP3 file.*/
			app->Decode_State = FILE_READ;
			break;
		}
		case FILE_READ:
		{
			/* Read some more data is the number of bytes
			 * left is less than a frame size and we have
			 * not reached the end of file.
			 */
			if(!KeepAlivemode)
			{
				if (BytesRemaning < MAINBUF_SIZE)
				{
					nRead = FillReadBuffer(app->pFIL, buffer, readPtr, BytesRemaning);
					BytesRemaning += nRead;
					readPtr = buffer;
					if (nRead == 0)
					{
						EndDecode(app);
						break;
					}
				}

				if(ContinueDecode(app)) app->Decode_State = MP3_DECODE;	/* Decode the frame */
				else
				{
					f_close(app->pFIL);
					app->Decode_State = PLAY_NEXT_FILE;
				}
				break;
			}
			else 
			{
				if(!KeepAlivebytesleft)
				{
					if(bbBUFFER_FULL_FLAG) break;
					if(bbBUFFER2_FULL_FLAG) break;
					KeepAliveReset(app);
					for(i=0; i<_NUM_CH; i++)
					{
						//app->CH_info.MuteGPIO[i]->BSRRH = app->CH_info.MuteGPIOpin[i];	/* Turn Off Output */
						app->CH_info.PlayState[i] = false;
						//app->CH_info.PlayCounter[i] = 0;
					}
					app->Decode_State = PLAYBACK_STOP;
					break;
				}
				/* Decode the frame */
				app->Decode_State = MP3_DECODE;
				break;
			}
		}
		case MP3_DECODE:
		{
			if(!bbBUFFER_FULL_FLAG)
			{
				if(!KeepAlivemode) err = MP3Decode(hMP3Decoder, &readPtr, &BytesRemaning, DecoderAudioBuffer.MP3Buffer.PCMbuffer1, 0);
				else err = MP3Decode(hMP3Decoder, &KeepAlivePtr, &KeepAlivebytesleft, DecoderAudioBuffer.MP3Buffer.PCMbuffer1, 0);
				app->Decode_State = FILE_READ;
				if (err)
				{
					/* error occurred */
					bbBUFFER_FULL_FLAG = BB_CLEAR_BIT;
					switch (err)
					{
						case (ERR_MP3_MAINDATA_UNDERFLOW):
							/* More data is needed. Read the file. */
								app->Decode_State = FILE_READ;
							break;
						case (ERR_MP3_INVALID_FRAMEHEADER):
								app->Decode_State = FRAME_SYNC_FIND;
							break;
						default:
							f_close(app->pFIL);
							app->Decode_State = PLAY_NEXT_FILE;
							break;
					}
				}
				bbBUFFER_FULL_FLAG = BB_SET_BIT;
				//if(!(SPI2->I2SCFGR & SPI_I2SCFGR_I2SE))
				//{
					/* Enable the I2S2 TxE interrupt */
				//	SPI_I2S_ITConfig(SPI2, SPI_I2S_IT_TXE, ENABLE);
					/* Enable the I2S2 */
				//	I2S_Cmd(SPI2, ENABLE);
				//}
				break;
			}

			if(!bbBUFFER2_FULL_FLAG)
			{
				if(!KeepAlivemode) err = MP3Decode(hMP3Decoder, &readPtr, &BytesRemaning, DecoderAudioBuffer.MP3Buffer.PCMbuffer2, 0);
				else err = MP3Decode(hMP3Decoder, &KeepAlivePtr, &KeepAlivebytesleft, DecoderAudioBuffer.MP3Buffer.PCMbuffer2, 0);
				app->Decode_State = FILE_READ;
				if (err)
				{
					// error occurred
					bbBUFFER2_FULL_FLAG = BB_CLEAR_BIT;
					switch (err)
					{
						case (ERR_MP3_MAINDATA_UNDERFLOW):
							/* More data is needed. Read the file. */
								app->Decode_State = FILE_READ;
							break;
						case (ERR_MP3_INVALID_FRAMEHEADER):
								app->Decode_State = FRAME_SYNC_FIND;
							break;
						default:
							f_close(app->pFIL);
							app->Decode_State = PLAY_NEXT_FILE;
							break;
					}
				}
				bbBUFFER2_FULL_FLAG = BB_SET_BIT;
				break;
			}
			break;
		}
		case WAV_DECODE:
		{
			if(!ContinueDecode(app))
			{
				f_close(app->pFIL);
				app->Decode_State = PLAY_NEXT_FILE;
				break;
			}
			if(!bbBUFFER_FULL_FLAG)
			{
				res = f_read(app->pFIL, DecoderAudioBuffer.WAVBuffer8.WAVBuffer8_1, WAVBUFFER8_SIZE, (UINT*)&BytesRemaning);     /* Read a chunk of src file */
				if (res)
				{
					app->Decode_State = IDLE_STATE;
					break;
				}
				if (BytesRemaning == 0)
				{
					EndDecode(app);
					break;
				}
				if(WaveFormat.DataLen >= BytesRemaning) WaveFormat.DataLen -= BytesRemaning;
				else
				{
					EndDecode(app);
					break;
				}
				bbBUFFER_FULL_FLAG = BB_SET_BIT;
				//if(!(SPI2->I2SCFGR & SPI_I2SCFGR_I2SE))
				//{
					/* Enable the I2S2 TxE interrupt */
				//	SPI_I2S_ITConfig(SPI2, SPI_I2S_IT_TXE, ENABLE);
					/* Enable the I2S2 */
				//	I2S_Cmd(SPI2, ENABLE);
				//}
				break;
			}
			if(!bbBUFFER2_FULL_FLAG)
			{
				res = f_read(app->pFIL, DecoderAudioBuffer.WAVBuffer8.WAVBuffer8_2, WAVBUFFER8_SIZE, (UINT*)&BytesRemaning);     /* Read a chunk of src file */
				if (res)
				{
					app->Decode_State = IDLE_STATE;
					break;
				}
				if (BytesRemaning == 0)
				{
					EndDecode(app);
					break;
				}
				if(WaveFormat.DataLen >= BytesRemaning) WaveFormat.DataLen -= BytesRemaning;
				else
				{
					EndDecode(app);
					break;
				}
				bbBUFFER2_FULL_FLAG = BB_SET_BIT;
				break;
			}
			break;
		}
		case PLAY_CURRENT_FILE:
		{
			if(bbBUFFER_FULL_FLAG) break;
			if(bbBUFFER2_FULL_FLAG) break;
			app->Decode_State = OPEN_FILE;
			break;
		}
		case PLAY_NEXT_FILE:
		{
			if(bbBUFFER_FULL_FLAG) break;
			if(bbBUFFER2_FULL_FLAG) break;
			for(i=0; i<_NUM_CH; i++)
			{
				if(app->CH_info.PlayState[i]) app->Decode_State = OPEN_FILE;
			}
			if(app->Decode_State == OPEN_FILE)
			{
				if(app->One_Second_Counters.StopTimeSec)
				{
					app->One_Second_Counters.StopTimeSec = 0;
					TrackCounter++;
					if(TrackCounter >= TracksOnCard) TrackCounter = 0x00;
				}
				else TrackCounter = 0x00;
			}
			else
			{
				app->One_Second_Counters.ResetVolCounter = app->Config_info.DefVolTimeSec;
				KeepAliveReset(app);
				app->Decode_State = PLAYBACK_STOP;
			}
			break;
		}
		case PLAYBACK_STOP:
		{
			if(bbBUFFER_FULL_FLAG) break;
			if(bbBUFFER2_FULL_FLAG) break;
			if(!(app->One_Second_Counters.KeepAliveCounter))
			{
				KeepAlivemode = 0x01;
				//app->CH_info.MuteGPIO[0]->BSRRL = app->CH_info.MuteGPIOpin[0];	/* Turn On Output */
				app->CH_info.PlayState[0] = true;
				app->Decode_State = FRAME_SYNC_FIND;
			}
			if(app->One_Second_Counters.ResetVolCounter) break;
			app->OutputVolumelevel = (app->Config_info.DefaultVolume << 1);
			break;
		}
		case PLAYBACK_PAUSE:
		{
			break;
		}
	}
}
