#include "board_conf.h"

#define SDIO_FIFO_ADDRESS			  ((uint32_t)0x40012C80)

void RCC_Configuration(void)
{
	/* Enable peripheral clocks ----------------------------------------------*/

	/* GPIOA Periph clock enable */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	/* GPIOB clock enable */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	/* GPIOC Periph clock enable */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	/* GPIOD Periph clock enable */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	/* SPI1 Peripheral clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
	/* SPI2 Peripheral clock enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
	/* SDIO Peripheral clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SDIO, ENABLE);
	/* TIM3 Periph clock enable */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	/* TIM9 Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9, ENABLE);
	/* TIM10 Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM10, ENABLE);
	/* TIM11 Periph clock enable */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM11, ENABLE);
	/* DMA2 Periph clock enable */
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE);
}

void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

   	/* Configure GPIOA pins for Output -------------------------------*/
	GPIO_InitStructure.GPIO_Pin   = LED8_Pin|LED9_Pin|SPI_CS_Pin|SW_E_Pin|SW_S0_Pin|SW_S1_Pin|SW_S2_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* Configure GPIOB pins for Output -------------------------------*/
	GPIO_InitStructure.GPIO_Pin   = RST_Pin|U_Pin|LED1_Pin|LED2_Pin|LED3_Pin|STATUS_LED_Pin;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* Configure GPIOC pins for Output -------------------------------*/
	GPIO_InitStructure.GPIO_Pin   = LED4_Pin|LED5_Pin|LED6_Pin|LED7_Pin|SD_EN_Pin;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/* Configure GPIOA pins for Input -------------------------------*/
	GPIO_InitStructure.GPIO_Pin   = SW7_Pin|SW8_Pin|SD_CD_Pin;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* Configure GPIOB pins for Input -------------------------------*/
	GPIO_InitStructure.GPIO_Pin   = INT_Pin|BLS_Pin|SW1_Pin|SW2_Pin|SW3_Pin;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* Configure GPIOC pins for Input -------------------------------*/
	GPIO_InitStructure.GPIO_Pin   = SW4_Pin|SW5_Pin|SW6_Pin|SW9_Pin;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/* Configure SPI1 pins: SCK, MISO, MOSI -------------------------------*/
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_SPI1);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_SPI1);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_SPI1);

	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* Configure SPI2 I2S pins: CK, WS and SD ---------------------------------*/
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_SPI2);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_SPI2);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_SPI2);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* Configure SPI2 I2S pins: MCK ---------------------------------*/
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_SPI2);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}

void I2S_Configuration(uint32_t AudioFreq)
{
	I2S_InitTypeDef I2S_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Disable the I2S2 TxE interrupt */
	//SPI_I2S_ITConfig(SPI2, SPI_I2S_IT_TXE, DISABLE);
	/* Disable the I2S2 */
	//SPI_I2S_DeInit(SPI2);
	/* Disable the I2S PLL */
	RCC->CR &= ~RCC_CR_PLLI2SON;

	if(AudioFreq == 8000ul) RCC_PLLI2SConfig(256, 5);
	else if(AudioFreq == 16000ul) RCC_PLLI2SConfig(213, 2);
	else if(AudioFreq == 32000ul) RCC_PLLI2SConfig(213, 2);
	else if(AudioFreq == 22050ul) RCC_PLLI2SConfig(429, 4);
	else if(AudioFreq == 48000ul) RCC_PLLI2SConfig(258, 3);
	else if(AudioFreq == 96000ul) RCC_PLLI2SConfig(344, 2);
	else RCC_PLLI2SConfig(271, 2);	//44100 and all others

	//RCC->PLLI2SCFGR |= 16;	// TODO Use only with 411, remove for 401

	/* Enable the I2S PLL */
	RCC->CR |= RCC_CR_PLLI2SON;
	/* Wait till the I2S PLL is ready */
	while((RCC->CR & RCC_CR_PLLI2SRDY) == 0)
	{
	}

	I2S_InitStructure.I2S_Standard = I2S_Standard_Phillips;
	I2S_InitStructure.I2S_DataFormat = I2S_DataFormat_16bextended;
	I2S_InitStructure.I2S_MCLKOutput = I2S_MCLKOutput_Enable;
	I2S_InitStructure.I2S_AudioFreq = AudioFreq;
	I2S_InitStructure.I2S_CPOL = I2S_CPOL_Low;
	I2S_InitStructure.I2S_Mode = I2S_Mode_MasterTx;
	I2S_Init(SPI2, &I2S_InitStructure);

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

	NVIC_InitStructure.NVIC_IRQChannel = SPI2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	if(!(SPI2->I2SCFGR & SPI_I2SCFGR_I2SE))
	{
		/* Enable the I2S2 TxE interrupt */
		SPI_I2S_ITConfig(SPI2, SPI_I2S_IT_TXE, ENABLE);
		/* Enable the I2S2 */
		I2S_Cmd(SPI2, ENABLE);
	}
}

void SPI_Configuration(void)
{
	SPI_InitTypeDef SPI_InitStructure;

	/* SPI1 Configuration ----------------------------------------------------*/
	//SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16; //SPI_BaudRatePrescaler_2;
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	SPI_InitStructure.SPI_CRCPolynomial = 7;
	SPI_Init(SPI1, &SPI_InitStructure);

	/* Enable SPI1 */
	SPI_Cmd(SPI1, ENABLE);
}

void SDIO_Configuration(void)
{
	DMA_InitTypeDef SDDMA_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	NVIC_PriorityGroupConfig (NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = SDIO_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init (&NVIC_InitStructure);
	NVIC_InitStructure.NVIC_IRQChannel = DMA2_Stream3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_Init (&NVIC_InitStructure);

	DMA_ClearFlag(SD_SDIO_DMA_STREAM_RX, SD_SDIO_DMA_FLAG_FEIF_RX | SD_SDIO_DMA_FLAG_DMEIF_RX | SD_SDIO_DMA_FLAG_TEIF_RX | SD_SDIO_DMA_FLAG_HTIF_RX | SD_SDIO_DMA_FLAG_TCIF_RX);

	/* DMA2 Stream3*/
	DMA_Cmd(SD_SDIO_DMA_STREAM_RX, DISABLE);

	/* DMA2 Stream3*/
	DMA_DeInit(SD_SDIO_DMA_STREAM_RX);

	SDDMA_InitStructure.DMA_Channel = SD_SDIO_DMA_CHANNEL_RX;
	SDDMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)SDIO_FIFO_ADDRESS;
	SDDMA_InitStructure.DMA_Memory0BaseAddr = 0ul;
	SDDMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
	SDDMA_InitStructure.DMA_BufferSize = 0;
	SDDMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	SDDMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	SDDMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	SDDMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	SDDMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	SDDMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	SDDMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;
	SDDMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	SDDMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_INC4;
	SDDMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_INC4;
	DMA_Init(SD_SDIO_DMA_STREAM_RX, &SDDMA_InitStructure);
	DMA_ITConfig(SD_SDIO_DMA_STREAM_RX, DMA_IT_TC, ENABLE);
	DMA_FlowControllerConfig(SD_SDIO_DMA_STREAM_RX, DMA_FlowCtrl_Peripheral);

}

void TIM3_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Set TIM3 Autoreload Register value */
	//TIM3->ARR = 63999;
	TIM3->ARR = 2500 - 1; //Interrupt every 250ms
	/* Set the Prescaler value */
	//TIM3->PSC = 270;
	TIM3->PSC = (uint16_t) ((SystemCoreClock / 10000) - 1); /* Compute the prescaler value to have TIMx counter clock equal to 10 KHz */
	/* Enable the Interrupt sources */
	TIM3->DIER |= TIM_IT_Update;
	/* Generate an update event to reload the Prescaler and the Repetition counter values immediately */
	TIM3->EGR = TIM_PSCReloadMode_Immediate;

	/* Enable and set Interrupt to the lowest priority */
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM3->CR1 |= TIM_CR1_ARPE;
	/* Enable TIM10 Counter */
	TIM3->CR1 |= TIM_CR1_CEN;
}

void TIM9_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Set TIM9 Autoreload Register value */
	TIM9->ARR = 63999;
	/* Set the Prescaler value */
	TIM9->PSC = 120;
	/* Enable the Interrupt sources */
	TIM9->DIER |= TIM_IT_Update;
	/* Generate an update event to reload the Prescaler and the Repetition counter values immediately */
	TIM9->EGR = TIM_PSCReloadMode_Immediate;

	/* Enable and set Interrupt to the lowest priority */
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_BRK_TIM9_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM9->CR1 |= TIM_CR1_ARPE;
	/* Enable TIM9 Counter */
	TIM9->CR1 |= TIM_CR1_CEN;
}

void TIM10_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Set TIM10 Autoreload Register value */
	TIM10->ARR = 63999;
	/* Set the Prescaler value */
	TIM10->PSC = 330;	//160;
	/* Enable the Interrupt sources */
	TIM10->DIER |= TIM_IT_Update;
	/* Generate an update event to reload the Prescaler and the Repetition counter values immediately */
	TIM10->EGR = TIM_PSCReloadMode_Immediate;

	/* Enable and set Interrupt to the lowest priority */
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_TIM10_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM10->CR1 |= TIM_CR1_ARPE;
	/* Enable TIM10 Counter */
	TIM10->CR1 |= TIM_CR1_CEN;
}

void TIM11_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Set TIM11 Autoreload Register value */
	TIM11->ARR = (uint16_t) ((SystemCoreClock / 1600ul)); //Set TIM11 to interrupt every second.
	/* Set the Prescaler value */
	TIM11->PSC = 1599;
	/* Enable the Interrupt sources */
	TIM11->DIER |= TIM_IT_Update;
	/* Generate an update event to reload the Prescaler and the Repetition counter values immediately */
	TIM11->EGR = TIM_PSCReloadMode_Immediate;

	/* Enable and set Interrupt to the lowest priority */
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_TRG_COM_TIM11_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM11->CR1 |= TIM_CR1_ARPE;
	/* Enable TIM11 Counter */
	TIM11->CR1 |= TIM_CR1_CEN;
}

void WDG_Configuration(void)
{
	/* Enable write access to IWDG_PR and IWDG_RLR registers */
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);

	/* IWDG counter clock: 40KHz(LSI) / 32 = 1.25KHz */
	IWDG_SetPrescaler(IWDG_Prescaler_32);

	/* Set counter reload value to Max timeout ~3276ms */
	IWDG_SetReload(0x0FFF);

	/* Reload IWDG counter */
	IWDG_ReloadCounter();

	/* Enable IWDG (the LSI oscillator will be enabled by hardware) */
	IWDG_Enable();
}

void SD_on(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	SD_PWR_ON;

	/* Configure SDIO pins ---------------------------------*/
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource8, GPIO_AF_SDIO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource9, GPIO_AF_SDIO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_SDIO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_SDIO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource12, GPIO_AF_SDIO);
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource2, GPIO_AF_SDIO);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
}

void SD_off(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	SD_PWR_OFF;

	/* Configure SDIO pins ---------------------------------*/
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource8, GPIO_AF_MCO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource9, GPIO_AF_MCO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_MCO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_MCO);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource12, GPIO_AF_MCO);
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource2, GPIO_AF_MCO);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Medium_Speed;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	GPIOC->BSRRH = GPIO_Pin_8;
	GPIOC->BSRRH = GPIO_Pin_9;
	GPIOC->BSRRH = GPIO_Pin_10;
	GPIOC->BSRRH = GPIO_Pin_11;
	GPIOC->BSRRH = GPIO_Pin_12;
	GPIOD->BSRRH = GPIO_Pin_2;

	SDIO_DeInit();
}

void SD_LowLevel_DMA_RxConfig(uint32_t *BufferDST, uint32_t BufferSize)
{

  //DMA_ClearFlag(SD_SDIO_DMA_STREAM, SD_SDIO_DMA_FLAG_FEIF | SD_SDIO_DMA_FLAG_DMEIF | SD_SDIO_DMA_FLAG_TEIF | SD_SDIO_DMA_FLAG_HTIF | SD_SDIO_DMA_FLAG_TCIF);
#define RESERVED_MASK           (uint32_t)0x0F7D0F7D
  DMA2->LIFCR = (uint32_t)((SD_SDIO_DMA_FLAG_FEIF_RX | SD_SDIO_DMA_FLAG_DMEIF_RX | SD_SDIO_DMA_FLAG_TEIF_RX | SD_SDIO_DMA_FLAG_HTIF_RX | SD_SDIO_DMA_FLAG_TCIF_RX) & RESERVED_MASK);

  /* DMA2 Stream3 disable */
  SD_SDIO_DMA_STREAM_RX->CR &= ~(uint32_t)DMA_SxCR_EN;

  SD_SDIO_DMA_STREAM_RX->NDTR = 0ul;
  SD_SDIO_DMA_STREAM_RX->M0AR = (uint32_t)BufferDST;

  /* DMA2 Stream3 enable */
  SD_SDIO_DMA_STREAM_RX->CR |= (uint32_t)DMA_SxCR_EN;
}

void SD_LowLevel_DMA_TxConfig(uint32_t *BufferSRC, uint32_t BufferSize)
{
	DMA_InitTypeDef SDDMA_InitStructure;

	DMA_ClearFlag(SD_SDIO_DMA_STREAM_TX, SD_SDIO_DMA_FLAG_FEIF_TX | SD_SDIO_DMA_FLAG_DMEIF_TX | SD_SDIO_DMA_FLAG_TEIF_TX | SD_SDIO_DMA_FLAG_HTIF_TX | SD_SDIO_DMA_FLAG_TCIF_TX);

	/* DMA2 Stream6 disable */
	DMA_Cmd(SD_SDIO_DMA_STREAM_TX, DISABLE);

	/* DMA2 Stream6 Config */
	DMA_DeInit(SD_SDIO_DMA_STREAM_TX);

	SDDMA_InitStructure.DMA_Channel = SD_SDIO_DMA_CHANNEL_TX;
	SDDMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)SDIO_FIFO_ADDRESS;
	SDDMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)BufferSRC;
	SDDMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	SDDMA_InitStructure.DMA_BufferSize = BufferSize;
	SDDMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	SDDMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	SDDMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word;
	SDDMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
	SDDMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	SDDMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	SDDMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;
	SDDMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;
	SDDMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_INC4;
	SDDMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_INC4;
	DMA_Init(SD_SDIO_DMA_STREAM_TX, &SDDMA_InitStructure);
	DMA_ITConfig(SD_SDIO_DMA_STREAM_TX, DMA_IT_TC, ENABLE);
	DMA_FlowControllerConfig(SD_SDIO_DMA_STREAM_TX, DMA_FlowCtrl_Peripheral);

	/* DMA2 Stream6 enable */
	DMA_Cmd(SD_SDIO_DMA_STREAM_TX, ENABLE);

}

