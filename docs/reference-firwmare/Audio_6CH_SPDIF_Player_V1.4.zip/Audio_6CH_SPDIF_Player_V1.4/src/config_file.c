
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "main.h"
#include "config_file.h"
#include "helper.h"

#define EEPROM_START	0x0800C000

#define sDEFVOL		"DefaultVolume=%u\n"
#define sMINVOL		"MinVolume=%u\n"
#define sMAXVOL		"MaxVolume=%u\n"
#define sPLAYTIME	"PlayTimeSeconds=%u\n"
#define sDEFVOLTIME	"DefaultVolumeTimeSeconds=%u\n"
#define sATTLEVEL	"Output%uAttenuationLevel=%u\n"
#define sYES		"yes\n"
#define sNO			"no\n"

#define strDEFVOL	"DefaultVolume="
#define strMINVOL	"MinVolume="
#define strMAXVOL	"MaxVolume="
#define strFLASH	"IdleFlashLED="
#define strSIM		"SimultaneousOutput="
#define strPLAYTIME	"PlayTimeSeconds="
#define strDEFVOLTIME	"DefaultVolumeTimeSeconds="
#define strATTLEVEL	"AttenuationLevel="

static void WriteFlashSettings(CONFIG_INFO* config)
{
	uint8_t i;
	uint32_t j = EEPROM_START;

	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR|FLASH_FLAG_PGSERR);
	if(FLASH_EraseSector(FLASH_Sector_3, VoltageRange_3) == FLASH_COMPLETE)
	{
		for(i=0; i<(7 + _NUM_CH); i++)
		{
			FLASH_ProgramByte(j, config->v[i]);
			j = j + 1ul;
		}
	}
	FLASH_Lock();
}

void LoadSettingsFile(FIL* fil, const char* file, CONFIG_INFO* config)
{
	uint8_t i;
	bool UpDateFlash = false;
	FRESULT fr;
	uint32_t temp32;
	char TempArray[4];
	char ConfigBuffer[32];

	fr = f_open(fil, file, FA_OPEN_EXISTING | FA_READ);
	if(fr == FR_NO_FILE)
	{
		f_close(fil);
		fr = f_open(fil, file, FA_CREATE_NEW | FA_WRITE);
		if(fr)
		{
			f_close(fil);
			return;
		}

		sprintf(ConfigBuffer, sDEFVOL, config->DefaultVolume);
		temp32 = f_puts(ConfigBuffer, fil);

		sprintf(ConfigBuffer, sMINVOL, config->MinVolume);
		temp32 = f_puts(ConfigBuffer, fil);

		sprintf(ConfigBuffer, sMAXVOL, config->MaxVolume);
		temp32 = f_puts(ConfigBuffer, fil);

		memset(ConfigBuffer, 0, 32);
		strcpy(ConfigBuffer, strFLASH);
		if(config->ButtonFlashLED) strcat(ConfigBuffer, sYES);
		else strcat(ConfigBuffer, sNO);
		temp32 = f_puts(ConfigBuffer, fil);

		memset(ConfigBuffer, 0, 32);
		strcpy(ConfigBuffer, strSIM);
		if(config->SimultaneousOutput) strcat(ConfigBuffer, sYES);
		else strcat(ConfigBuffer, sNO);
		temp32 = f_puts(ConfigBuffer, fil);

		sprintf(ConfigBuffer, sPLAYTIME, config->PlayTimeSec);
		temp32 = f_puts(ConfigBuffer, fil);

		sprintf(ConfigBuffer, sDEFVOLTIME, config->DefVolTimeSec);
		temp32 = f_puts(ConfigBuffer, fil);

		for(i=0; i<_NUM_CH; i++)
		{
			sprintf(ConfigBuffer, sATTLEVEL, i+1, config->AttLevel[i]);
			temp32 = f_puts(ConfigBuffer, fil);
		}

		f_close(fil);

		DMA_ClearFlag(SD_SDIO_DMA_STREAM_TX, SD_SDIO_DMA_FLAG_FEIF_TX | SD_SDIO_DMA_FLAG_DMEIF_TX | SD_SDIO_DMA_FLAG_TEIF_TX | SD_SDIO_DMA_FLAG_HTIF_TX | SD_SDIO_DMA_FLAG_TCIF_TX);
		/* DMA2 Stream6 disable */
		DMA_Cmd(SD_SDIO_DMA_STREAM_TX, DISABLE);
		/* DMA2 Stream6 Config */
		DMA_DeInit(SD_SDIO_DMA_STREAM_TX);

		fr = f_open(fil, file, FA_OPEN_EXISTING | FA_READ);
	}
	if(fr)
	{
		f_close(fil);
		return;
	}
	memset(ConfigBuffer, 0, 32);
	while(f_gets(ConfigBuffer, sizeof ConfigBuffer, fil))
	{
		if(strstr(ConfigBuffer, strDEFVOL))
		{
			temp32 = atoi(&ConfigBuffer[14]);	//temp32 = atoi(&ConfigBuffer[sizeof(strDEFVOL) - 2]);
			if(config->DefaultVolume != (uint8_t)temp32) UpDateFlash = true;
			if(temp32 <= MAX_VOL) config->DefaultVolume = (uint8_t)temp32;
			else
			{
				config->DefaultVolume = DEF_VOL;
				UpDateFlash = true;
			}
			continue;
		}
		if(strstr(ConfigBuffer, strMINVOL))
		{
			temp32 = atoi(&ConfigBuffer[10]);
			if(config->MinVolume != (uint8_t)temp32) UpDateFlash = true;
			if(temp32 <= MAX_VOL) config->MinVolume = (uint8_t)temp32;
			else
			{
				config->MinVolume = MIN_VOL;
				UpDateFlash = true;
			}
			continue;
		}
		if(strstr(ConfigBuffer, strMAXVOL))
		{
			temp32 = atoi(&ConfigBuffer[10]);
			if(config->MaxVolume != (uint8_t)temp32) UpDateFlash = true;
			if(temp32 <= MAX_VOL) config->MaxVolume = (uint8_t)temp32;
			else
			{
				config->MaxVolume = MAX_VOL;
				UpDateFlash = true;
			}
			continue;
		}
		if(strstr(ConfigBuffer, strATTLEVEL))	/* OutputxAttenuationLevel= */
		{
			temp32 = atoi(&ConfigBuffer[6]);	/* Outputx */
			if(temp32 <= _NUM_CH)
			{
				i = (uint8_t)--temp32;
				temp32 = atoi(&ConfigBuffer[24]);
				if(config->AttLevel[i] != (uint8_t)temp32) UpDateFlash = true;
				if(temp32 <= ATTLEVEL) config->AttLevel[i] = (uint8_t)temp32;
				else
				{
					config->AttLevel[i] = ATTLEVEL;
					UpDateFlash = true;
				}
			}
			continue;
		}
		if(strstr(ConfigBuffer, strFLASH))
		{
			memset(TempArray, 0, 4);
			memcpy(TempArray, &ConfigBuffer[13], 4);
			TempArray[3] = 0;
			StrLower(TempArray);
			if(strstr(TempArray, "no"))
			{
				if(config->ButtonFlashLED) UpDateFlash = true;
				config->ButtonFlashLED = false;
			}
			else
			{
				if(!config->ButtonFlashLED) UpDateFlash = true;
				config->ButtonFlashLED = true;
			}
			continue;
		}
		if(strstr(ConfigBuffer, strSIM))
		{
			memset(TempArray, 0, 4);
			memcpy(TempArray, &ConfigBuffer[19], 4);
			TempArray[3] = 0;
			StrLower(TempArray);
			if(strstr(TempArray, "no"))
			{
				if(config->SimultaneousOutput) UpDateFlash = true;
				config->SimultaneousOutput = false;
			}
			else
			{
				if(!config->SimultaneousOutput) UpDateFlash = true;
				config->SimultaneousOutput = true;
			}
			continue;
		}
		if(strstr(ConfigBuffer, strPLAYTIME))
		{
			temp32 = atoi(&ConfigBuffer[16]);
			if(config->PlayTimeSec != (uint8_t)temp32) UpDateFlash = true;
			if(temp32 <= 255ul) config->PlayTimeSec = (uint8_t)temp32;
			else
			{
				config->PlayTimeSec = PLAYTIMESEC;
				UpDateFlash = true;
			}
			continue;
		}
		if(strstr(ConfigBuffer, strDEFVOLTIME))
		{
			temp32 = atoi(&ConfigBuffer[25]);
			if(config->DefVolTimeSec != (uint8_t)temp32) UpDateFlash = true;
			if(temp32 <= 255ul) config->DefVolTimeSec = (uint8_t)temp32;
			else
			{
				config->DefVolTimeSec = RESETVOLTIME;
				UpDateFlash = true;
			}
		}
		memset(ConfigBuffer, 0, 32);
	}
	if(config->MinVolume > config->MaxVolume)
	{
		config->MinVolume = config->MaxVolume;
		UpDateFlash = true;
	}
	if(config->MaxVolume < config->MinVolume)
	{
		config->MaxVolume = config->MinVolume;
		UpDateFlash = true;
	}
	if(config->DefaultVolume > config->MaxVolume)
	{
		config->DefaultVolume = config->MaxVolume;
		UpDateFlash = true;
	}
	if(config->DefaultVolume < config->MinVolume)
	{
		config->DefaultVolume = config->MinVolume;
		UpDateFlash = true;
	}

	f_close(fil);

	if(UpDateFlash == true) WriteFlashSettings(config);
}
