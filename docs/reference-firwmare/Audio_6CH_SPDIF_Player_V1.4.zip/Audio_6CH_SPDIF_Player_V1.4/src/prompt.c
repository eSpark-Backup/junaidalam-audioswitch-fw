
#include "prompt.h"
#include "decode.h"
#include "startup_stm32f4xx.h"
#include "config_file.h"
#include <string.h>

#define	VERSION_MAJOR	(Version_PCB / 10U)
#define	VERSION_MINOR	(Version_PCB % 10U)

const char *PromptFilename[] = {
		"one.mp3",		//0	Temp placeholder for Zero.mp3
		"one.mp3",		//1
		"two.mp3",		//2
		"three.mp3",	//3
		"four.mp3",		//4
		"five.mp3",		//5
		"six.mp3",		//6
		"seven.mp3",	//7
		"eight.mp3",	//8
		"nine.mp3",		//9
		"ten.mp3",		//10
		"pprompt6.mp3",	//11 Firmware version
		"pprompt1.mp3",	//12 Programming mode
		"pprompt2.mp3",	//13 Playback default volume is currently set to
		"pprompt3.mp3",	//14 Press volume up to change the default volume setting.  When the desired setting is reached please wait, after five seconds of inactivity the system will automatically save the new setting.
		"pprompt4.mp3",	//15 Saving default settings and exiting programming mode
		"pprompt7.mp3",	//16 Exiting programming mode due to inactivity.
};

static uint8_t count = 0;

static void AllLEDsOutputsOff(APP_PLAYER *app)
{
	uint8_t i;

	for(i=0; i<_NUM_CH; i++)
	{
		//app->CH_info.MuteGPIO[i]->BSRRH = app->CH_info.MuteGPIOpin[i];	/* Turn Off Output */
		app->CH_info.LEDGPIO[i]->BSRRH = app->CH_info.LEDGPIOpin[i];	// All LEDs off
	}
	LED_VOLUP_OFF;
	LED_VOLDN_OFF;
}

static void Playtrack(APP_PLAYER *app, uint8_t track, uint8_t channel)
{
	uint8_t j;

	strcpy(drvTracks, strPromptDIR);
	strcat(drvTracks, PromptFilename[track]);

	if(app->Config_info.SimultaneousOutput)
	{
		for(j=0; j<_NUM_CH; j++)
		{
			app->CH_info.PlayCounter[j] = 0;	/* Turn On All Outputs */
			app->CH_info.PlayState[j] = true;
		}
	}
	else
	{
		app->CH_info.PlayCounter[channel] = 0;	/* Turn On Outputs */
		app->CH_info.PlayState[channel] = true;
	}

	app->OutputAttLevel = (float)app->Config_info.AttLevel[0];
	app->OutputAttLevel = app->OutputAttLevel / 50;	//100;
	app->Decode_State = OPEN_FILE;
	app->One_Second_Counters.PromptEnterExitTimeSec = 10;
}

void PromptScanButtons(APP_PLAYER *app)
{
	static KEY_STATE keystate = UP;
	FRESULT fr;
	uint8_t i;

	switch(app->Prompt_State)
	{
		case ENTER_STATE:
		{
			for(i=0; i<_NUM_CH; i++)
			{
				app->CH_info.keyState[i] = UP;
				app->CH_info.PlayState[i] = false;
				app->CH_info.PlayCounter[i] = 0x00;
			}
			AllLEDsOutputsOff(app);
			keystate = UP;
			count = 0;
			app->One_Second_Counters.PromptEnterExitTimeSec = 10;
			app->Decode_State = PLAYBACK_STOP;
			app->Prompt_State = ENTER_VOLDN_STATE;
			break;
		}
		case ENTER_VOLDN_STATE:
		{
			if(!app->One_Second_Counters.PromptEnterExitTimeSec) app->Prompt_State = EXIT_STATE;
			if(!(VOL_DN))
			{
				if(keystate == UP)	/* First Time Pressed? */
				{
					keystate = DOWN;
					count++;
					if(count >= 3)	// the user has to press volume down three times.
					{
						count = 0;
						keystate = UP;
						app->Prompt_State = PROG_MODE;
						app->One_Second_Counters.PromptEnterExitTimeSec = 10;
					}
				}
			}
			else keystate = UP;

			break;
		}
		case PROG_MODE:
		{
			Playtrack(app, 11, 0); //11 Firmware version
			app->Prompt_State = VER_MAJOR;
			break;
		}
		case VER_MAJOR:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			Playtrack(app, VERSION_MAJOR, 0); //Firmware Major
			app->Prompt_State = VER_MINOR;
			break;
		}
		case VER_MINOR:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			Playtrack(app, VERSION_MINOR, 0); //Firmware Minor
			app->Prompt_State = PROG_TRACK;
			break;
		}
		case PROG_TRACK:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			Playtrack(app, 12, 0); //12 Programming mode
			app->Prompt_State = DEFAULT_VOL;
		}
		case DEFAULT_VOL:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			Playtrack(app, 13, 0); //13 Playback default volume is currently set to
			app->Prompt_State = DEFAULT_VOL_SET;
			break;
		}
		case DEFAULT_VOL_SET:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			Playtrack(app, app->Config_info.DefaultVolume, 0); //Default_volume
			app->Prompt_State = DEFAULT_VOL_CHANGE;
			break;
		}
		case DEFAULT_VOL_CHANGE:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			Playtrack(app, 14, 0); //14 Press volume up to change the default volume setting.  When the desired setting is reached please wait, after five seconds of inactivity the system will automatically save the new setting.
			app->Prompt_State = DEFAULT_VOL_CHANGE_WAIT;
			break;
		}
		case DEFAULT_VOL_CHANGE_WAIT:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			app->Prompt_State = DEFAULT_VOL_INPUT;
			app->One_Second_Counters.PromptTimeSec = 9;
			break;
		}

		case DEFAULT_VOL_INPUT:
		{
			//if(app->Decode_State != PLAYBACK_STOP) break;
			if(!app->One_Second_Counters.PromptTimeSec)
			{
				count++;
				if(count > 1) app->Prompt_State = EXIT_PROG_INACTIVITY;
				else app->Prompt_State = DEFAULT_VOL_CHANGE;
			}
			if(!(VOL_UP))
			{
				keystate = UP;
				count = 0;
				app->One_Second_Counters.PromptTimeSec = 8;
				app->Prompt_State = DEFAULT_VOL_SCROLL;
			}
			break;
		}
		case DEFAULT_VOL_SCROLL:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			if(!app->One_Second_Counters.PromptTimeSec) app->Prompt_State = DEFAULT_VOL_SAVE;
			if(!(VOL_UP))
			{
				if(keystate == UP)	/* First Time Pressed? */
				{
					keystate = DOWN;
					app->One_Second_Counters.PromptTimeSec = 8;
					app->Config_info.DefaultVolume++;
					if(app->Config_info.DefaultVolume > 10) app->Config_info.DefaultVolume = 1;
					app->OutputVolumelevel = (app->Config_info.DefaultVolume << 1);
					Playtrack(app, app->Config_info.DefaultVolume, 0); //Default_volume
				}
			}
			else keystate = UP;
			break;
		}
		case DEFAULT_VOL_SAVE:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			LED_VOLUP_OFF;
			fr = f_unlink("SD:Config.txt");
			if(fr == FR_OK)
			{
				LoadSettingsFile(app->pFIL, "SD:Config.txt", &app->Config_info);
				Playtrack(app, 15, 0); //15 Saving default settings and exiting programming mode
				app->OutputVolumelevel = 12;
			}
			app->Prompt_State = EXIT_STATE;
			break;
		}
		case EXIT_PROG_INACTIVITY:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			Playtrack(app, 16, 0); //16 Exiting programming mode due to inactivity.
			app->Prompt_State = EXIT_STATE;
			break;
		}
		case EXIT_STATE:
		{
			if(app->Decode_State != PLAYBACK_STOP) break;
			ClearFlags();
			TIM10->PSC = 330;	//Set the Prescaler value back from LED fast flash
			app->One_Second_Counters.PromptEnterExitTimeSec = 10;
			app->OutputVolumelevel = (app->Config_info.DefaultVolume << 1);
			break;
		}
	}
}

void PromptSetButtonLEDs(APP_PLAYER *app)
{

	if(app->Prompt_State == ENTER_VOLDN_STATE)
	{
		if(app->CH_info.LEDGPIO[0]->IDR & app->CH_info.LEDGPIOpin[0]) app->CH_info.LEDGPIO[0]->BSRRH = app->CH_info.LEDGPIOpin[0];	// LED off
		else app->CH_info.LEDGPIO[0]->BSRRL = app->CH_info.LEDGPIOpin[0];	// LED on
	}
	if(((app->Prompt_State == DEFAULT_VOL_INPUT) && (app->Decode_State == PLAYBACK_STOP)) || app->Prompt_State == DEFAULT_VOL_SCROLL)
	{
		if(LED_VOLUP_STATE) LED_VOLUP_OFF;
		else LED_VOLUP_ON;
	}
}
