#include "startup_stm32f4xx.h"
#include "LEDs.h"
#include "diskio.h"

#define	COPFlashH	(Version_PCB / 10U)
#define	COPFlashL	(Version_PCB % 10U) * 2U

void SetCOPLED(APP_PLAYER *app)
{
	static uint8_t COPFlashflag = 0x00;
	static uint8_t COP750ms = 0x00;

	if((app->Decode_State < OPEN_CONFIG) || (*app->Media_State == NO_MEDIA_INIT)) TOGGLE_COP_LED;
	else
	{
		if(COPFlashflag < COPFlashH)
		{
			if(COP750ms < 3)
			{
				COP_ON;
				COP750ms++;
			}
			else
			{
				COP_OFF;
				COP750ms = 0;
			}
		}
		else if(COPFlashflag < COPFlashH + 0x05)
		{
			COP_OFF;
		}
		else if(COPFlashflag < (COPFlashL + COPFlashH + 0x05))
		{
			TOGGLE_COP_LED;
		}
		if(COP750ms > 2) COPFlashflag++;
		if(COPFlashflag > (COPFlashL + COPFlashH + 0x0E)) COPFlashflag = 0x00;
	}
}

uint32_t SetButtonLEDs(APP_PLAYER *app, uint32_t led_flag)
{
	uint32_t i;
	uint32_t j;

	//CH_INFO* ch = &app->CH_info;

	disk_timerproc();

	if(led_flag) led_flag = BB_CLEAR_BIT;
	else led_flag = BB_SET_BIT;

	for(i=0; i<_NUM_CH; i++)
	{
		if(app->CH_info.PlayState[i])
		{
			if(app->Config_info.ButtonFlashLED) app->CH_info.LEDGPIO[i]->BSRRL = app->CH_info.LEDGPIOpin[i];
			else
			{
				if(led_flag) app->CH_info.LEDGPIO[i]->BSRRH = app->CH_info.LEDGPIOpin[i];
				else app->CH_info.LEDGPIO[i]->BSRRL = app->CH_info.LEDGPIOpin[i];
			}
		}
		else
		{
			if(app->Config_info.ButtonFlashLED)
			{
				if(led_flag) app->CH_info.LEDGPIO[i]->BSRRH = app->CH_info.LEDGPIOpin[i];
				else app->CH_info.LEDGPIO[i]->BSRRL = app->CH_info.LEDGPIOpin[i];
			}
			else app->CH_info.LEDGPIO[i]->BSRRL = app->CH_info.LEDGPIOpin[i];
		}
	}

	j = 0;
	for(i=0; i<_NUM_CH; i++)
	{
		if(app->CH_info.PlayState[i]) j = 1;
	}
	if(j)
	{
		if(!(VOL_UP))
		{
			if(app->OutputVolumelevel < (app->Config_info.MaxVolume << 1)) app->OutputVolumelevel++;
			else app->OutputVolumelevel = (app->Config_info.MaxVolume << 1);

			if(led_flag) LED_VOLUP_OFF;
			else LED_VOLUP_ON;
		}
		else LED_VOLUP_ON;

		if(!(VOL_DN))
		{
			if(app->OutputVolumelevel > (app->Config_info.MinVolume << 1)) app->OutputVolumelevel--;
			else app->OutputVolumelevel = (app->Config_info.MinVolume << 1);

			if(led_flag) LED_VOLDN_OFF;
			else LED_VOLDN_ON;
		}
		else LED_VOLDN_ON;
	}
	else
	{
		LED_VOLUP_ON;
		LED_VOLDN_ON;
	}

	return led_flag;
}
