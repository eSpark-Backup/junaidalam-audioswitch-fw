#include "spiflash.h"
#include "main.h"

#define PP		0x02	//Page Program
#define READ	0x03
#define RDSR1	0x05	//Read Status Register 1
#define WREN	0x06	//Write Enable
#define PP4		0x12	//Page Program 4 Byte Address
#define READ4	0x13	//Read 4 Byte Address
#define SE		0x20	//Sector Erase
#define SE4		0x21	//Sector Erase 4 Byte Address
#define READID	0x9F

#define FOUR_BYTE_ADDRESS 1
#define SECTORSIZE	0x1000	//4096 Bytes

typedef union
{
	uint32_t Val;
	uint8_t Byte[4];
} VAL32;

static uint8_t PageProg(uint8_t *pData, uint32_t PageAddress);
static uint8_t SPIflashSectorErase(uint32_t SectorAddr, uint32_t NumOfSectors);

static uint8_t WriteEnable(void)
{
	NOR_SPI_CS_LOW;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = WREN;	//Write Enable
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_CS_HIGH;
	/* Return the data in the DR register */
	return NOR_SPI_DR;
}

void WriteDone(void)
{
	uint8_t temp;

	temp = 0x01;
	while((temp & 0x01) == 0x01)
	{
		NOR_SPI_CS_LOW;
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = RDSR1;	//Read Status Register 1
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		temp = NOR_SPI_DR;
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = 0x00;
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		temp = NOR_SPI_DR;
		NOR_SPI_CS_HIGH;
	}
}

uint32_t SPIflashReadID(void)
{
	VAL32 Data;

	Data.Val = 0ul;

	NOR_SPI_CS_LOW;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = READID;
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = 0x00;
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	Data.Byte[2] = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = 0x00;
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	Data.Byte[1] = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = 0x00;
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	Data.Byte[0] = NOR_SPI_DR;
	NOR_SPI_CS_HIGH;

	return Data.Val;

}

uint8_t SPIflashWriteSector(uint8_t *pBuffer, uint32_t WriteAddr, uint32_t NumSectorToWrite)
{
	uint8_t ret;

	SPIflashSectorErase(WriteAddr, NumSectorToWrite);

	NumSectorToWrite *= SECTORSIZE;

	while(NumSectorToWrite)
	{
		WriteDone();
		PageProg(pBuffer, WriteAddr);
		WriteAddr += 256ul;
		pBuffer += 256ul;
		NumSectorToWrite -= 256ul;
	}
	return ret = 0;
}

#if FOUR_BYTE_ADDRESS
static uint8_t PageProg(uint8_t *pData, uint32_t PageAddress)
{
	uint8_t *pD = pData;
	uint16_t counter;
	uint8_t ret;
	VAL32 Address;

	WriteEnable();

    NOR_SPI_CS_LOW;
    Address.Val = PageAddress;
    while (!(NOR_SPI_SR & SPI_SR_TXE));
    NOR_SPI_DR = PP4;	//Page Program
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[3];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[2];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[1];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[0];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
    // WRITE
    for(counter = 0; counter < 256; counter++)
    {
    	//while (!(NOR_SPI_SR & SPI_SR_TXE));
    	NOR_SPI_DR = *pD++;
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		NOR_SPI_DR;
    }
    NOR_SPI_CS_HIGH;
    return ret = 0;
}

static uint8_t SPIflashSectorErase(uint32_t SectorAddr, uint32_t NumOfSectors)
{
	uint8_t ret;
	uint32_t counter;
	VAL32 Address;

	Address.Val = SectorAddr;

	for(counter = 0; counter < NumOfSectors; counter++)
	{
		WriteDone();
		WriteEnable();

		NOR_SPI_CS_LOW;
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = SE4;	//Sector Erase
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		NOR_SPI_DR;
		//while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = Address.Byte[3];
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		NOR_SPI_DR;
		//while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = Address.Byte[2];
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		NOR_SPI_DR;
		//while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = Address.Byte[1];
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		NOR_SPI_DR;
		//while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = Address.Byte[0];
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		NOR_SPI_DR;
		NOR_SPI_CS_HIGH;

		Address.Val += SECTORSIZE;
	}
	return ret = 0;
}

uint8_t SPIflashReadBytes(uint8_t *pBuffer,uint32_t ReadAddr,uint32_t NumByteToRead)
{
	VAL32 Address;
	uint8_t ret;
	
	NOR_SPI_CS_LOW;
	Address.Val = ReadAddr;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = READ4;	//4 Byte Address READ
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[3];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[2];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[1];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;
	//while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[0];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	NOR_SPI_DR;

	while(NumByteToRead--)
	{
		//while (!(NOR_SPI_SR & SPI_SR_TXE));	//Slower SPI clock rate might need to enable this line
		NOR_SPI_DR = 0x00;
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		*pBuffer++ = NOR_SPI_DR;
	}
	NOR_SPI_CS_HIGH;
	return ret = 0;
}

#else

static uint8_t PageProg(uint8_t *pData, uint32_t PageAddress)
{
	uint8_t *pD = pData;
	uint16_t counter;
	uint8_t ret;

	VAL32 Address;

	Address.Val = PageAddress;

	WriteEnable();

    NOR_SPI_CS_LOW;
    while (!(NOR_SPI_SR & SPI_SR_TXE));
    NOR_SPI_DR = PP;	//Page Program
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[2];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[1];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[0];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;

    // WRITE
    for(counter = 0; counter < 256; counter++)
    {
    	while (!(NOR_SPI_SR & SPI_SR_TXE));
    	NOR_SPI_DR = *pD++;
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		ret = NOR_SPI_DR;
    }

    NOR_SPI_CS_HIGH;
    return ret = 0;
}

static uint8_t SPIflashSectorErase(uint32_t SectorAddr, uint32_t NumOfSectors)
{
	uint8_t ret;
	uint32_t counter;
	VAL32 Address;

	Address.Val = SectorAddr;

	for(counter = 0; counter < NumOfSectors; counter++)
	{
		WriteEnable();

		NOR_SPI_CS_LOW;
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = SE;	//Sector Erase
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		ret = NOR_SPI_DR;
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = Address.Byte[2];
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		ret = NOR_SPI_DR;
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = Address.Byte[1];
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		ret = NOR_SPI_DR;
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = Address.Byte[0];
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		ret = NOR_SPI_DR;
		NOR_SPI_CS_HIGH;

		Address.Val += SECTORSIZE;

		WriteDone();
	}
	return ret = 0;
}

uint8_t SPIflashReadBytes(uint8_t *pBuffer,uint32_t ReadAddr,uint32_t NumByteToRead)
{
	VAL32 Address;
	uint8_t ret;

	Address.Val = ReadAddr;
	NOR_SPI_CS_LOW;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = READ;	//3 Byte Address READ
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[2];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[1];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;
	while (!(NOR_SPI_SR & SPI_SR_TXE));
	NOR_SPI_DR = Address.Byte[0];
	while (!(NOR_SPI_SR & SPI_SR_RXNE));
	ret = NOR_SPI_DR;

	while(NumByteToRead--)
	{
		while (!(NOR_SPI_SR & SPI_SR_TXE));
		NOR_SPI_DR = 0x00;
		while (!(NOR_SPI_SR & SPI_SR_RXNE));
		*pBuffer++ = NOR_SPI_DR;
	}
	NOR_SPI_CS_HIGH;
	return ret = 0;
}

#endif
