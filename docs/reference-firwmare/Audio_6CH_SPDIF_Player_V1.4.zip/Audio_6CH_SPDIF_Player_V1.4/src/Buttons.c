#include "Buttons.h"

void ScanButtons(APP_PLAYER *app)
{
	static KEY_STATE keyDemoState2 = UP;
	uint8_t i;

	for(i=0; i<_NUM_CH; i++)
	{
		if(!(app->CH_info.KeyGPIO[i]->IDR & app->CH_info.KeyGPIOpin[i])) /* Key Pressed? */
		{
			if(app->CH_info.keyState[i] == UP)	/* First Time Pressed? */
			{
				app->CH_info.keyState[i] = DOWN;
				if(app->CH_info.PlayState[i]) /* Check If Output Is Playing */
				{
					//app->CH_info.MuteGPIO[0]->BSRRH = app->CH_info.MuteGPIOpin[0];	/* Mute Output */
					app->CH_info.LastPlayCounter[i] = app->CH_info.PlayCounter[i];
					app->CH_info.PlayCounter[i] = 0x00;
					app->CH_info.PlayState[i] = false;
					app->One_Second_Counters.StopTimeSec = 0x04;
					app->One_Second_Counters.PauseTimeoutSec = 30;
					app->Last_Decode_State = app->Decode_State;
					app->Decode_State = PLAYBACK_PAUSE;
				}
				else
				{
					for(uint8_t j=0; j<_NUM_CH; j++)
					{
						app->CH_info.PlayCounter[j] = 0x00;
						app->CH_info.PlayState[j] = false;
					}
					if(app->One_Second_Counters.PauseTimeoutSec)
					{
						app->One_Second_Counters.PauseTimeoutSec = 0x00;
						app->CH_info.PlayCounter[i] = app->CH_info.LastPlayCounter[i];
						app->Decode_State = app->Last_Decode_State;
					}
					else
					{
						app->CH_info.PlayCounter[i] = app->Config_info.PlayTimeSec;	/* Turn On Output */
						app->OutputAttLevel = (float)app->Config_info.AttLevel[i];
						app->OutputAttLevel = app->OutputAttLevel / 50;
						app->One_Second_Counters.StopTimeSec = 0x04;
						app->Decode_State = PLAY_NEXT_FILE;
					}
					app->CH_info.PlayState[i] = true;
				}
			}
		}
		else app->CH_info.keyState[i] = UP;
	}

	if(!(DEMO2))
	{
		if(keyDemoState2 == UP)
		{
			for(i=0; i<_NUM_CH; i++)
			{
				if(app->CH_info.PlayState[i]) /* Check If Output Is Playing */
				{
					LED_DEMO2_OFF;
					keyDemoState2 = DOWN;
					app->CH_info.PlayCounter[i] = app->Config_info.PlayTimeSec;	/* Turn On Output */
					app->CH_info.PlayState[i] = true;
					app->OutputAttLevel = (float)app->Config_info.AttLevel[i];
					app->OutputAttLevel = app->OutputAttLevel / 50;
					app->One_Second_Counters.StopTimeSec = 0x04;
					//KeepAliveReset();
					app->Decode_State = PLAY_NEXT_FILE;
				}
			}
		}
	}
	else
	{
		LED_DEMO2_ON;
		keyDemoState2 = UP;
	}

	if(app->CH_info.keyState[0] == UP) app->One_Second_Counters.PromptEnterExitTimeSec = 10;
}
