#include "i2c.h"

//-------------------------------------------
// Definition of local constants
//-------------------------------------------
#define I2C_TIMEOUT  (0x1000)

typedef enum {
	I2C_OK = 0,		/* 0: Successful */
	I2C_ERROR		/* 1: I2C Error */
} I2C_RESULT;

//-------------------------------------------
// Declaration of local functions
//-------------------------------------------
static uint8_t I2C_check_dev(I2C_TypeDef* Open_I2C, uint8_t addr);
static uint8_t I2C_start(I2C_TypeDef* I2Cx, uint8_t addr, uint8_t rdwr);
static uint8_t I2C_restart(I2C_TypeDef* I2Cx, uint8_t addr, uint8_t rdwr);
static uint8_t I2C_write(I2C_TypeDef* I2Cx, uint8_t data);
static uint8_t I2C_read_ack(I2C_TypeDef* I2Cx);
static uint8_t I2C_read_nack(I2C_TypeDef* I2Cx);


//===============================================================================
// I2C_ReadTransfer - initiate a read transfer on the I2C bus
//
// Initiates a read transfer on the I2C bus.
// If a register address is specified (<addressLength> != 0) a write without a stop
// condition will be initiated to the device to write the address, before the
// read is initiated.
// If no address if required (sequential read) <addressLength> is set to 0.
//-------------------------------------------------------------------------------
// u08 dev_addr  I2C device address
// u08 *buffer   pointer to the buffer to store the read data.
//               The buffer must be at least 'cnt' bytes long
// int cnt       number of bytes to read
// u32 ptr       register address, if required by the I2C-device
// u08 ptrlen    length of the register address to be written.
//               Valid values are 0..4
//-------------------------------------------------------------------------------
uint8_t I2C_ReadTransfer(I2C_TypeDef* Open_I2C, uint8_t dev_addr, uint8_t *buffer, uint32_t cnt, uint32_t ptr, uint8_t ptrlen)
{
	uint32_t i;
	uint8_t rc = I2C_OK;

  //-----------------------------------------------------------------------------
  // parameter check
  //-----------------------------------------------------------------------------
  if ((buffer == 0) || (ptrlen > 4) || ((cnt | ptrlen) == 0))
  {
    return I2C_check_dev(Open_I2C, dev_addr); // may be used to check if device is responding
  }
  //-----------------------------------------------------------------------------
  // write the register address pointer to the device
  //-----------------------------------------------------------------------------
  if (ptrlen > 0)
  {
    rc = I2C_start(Open_I2C, dev_addr, I2C_Direction_Transmitter);
    if (rc == I2C_OK)
    {
      for (i=1; i<=ptrlen; i++)
      {
        rc |= I2C_write(Open_I2C,((ptr >>(8*(ptrlen-i))) & 0xff));
      }
    }
  }
  //-----------------------------------------------------------------------------
  // read data from device
  //-----------------------------------------------------------------------------
  if ((cnt > 0) && (rc == I2C_OK))
  {
    if (ptrlen > 0)
    {
      rc |= I2C_restart(Open_I2C, dev_addr, I2C_Direction_Receiver);
    }
    else
    {
      rc |= I2C_start(Open_I2C, dev_addr, I2C_Direction_Receiver);
    }
    if (rc == I2C_OK)
    {
      while (--cnt>0)                         // while more than one byte to read
      {
        *(buffer++) = I2C_read_ack(Open_I2C); // read next databyte from I2C device
      }

      *(buffer) = I2C_read_nack(Open_I2C);    // read last databyte from I2C device
    }
  }
  //-----------------------------------------------------------------------------
  I2C_GenerateSTOP(Open_I2C, ENABLE);                        // stop the transmission
  return rc;
}


//===============================================================================
// I2C_WriteTransfer r- initiate a write transfer on the I2C bus
//
// Initiates a write transfer on the I2C bus.
// If a register address is supplied it is inserted between the I2C device address
// and the data.
//-------------------------------------------------------------------------------
// u08 dev_addr  I2C device address
// u08 *buffer   pointer to the buffer to store the read data.
//               The buffer must be at least 'cnt' bytes long
// int cnt       number of bytes to read
// u32 ptr       register address, if required by the I2C-device
// u08 ptrlen    length of the register address to be written.
//               Valid values are 0..4
//-------------------------------------------------------------------------------
uint8_t I2C_WriteTransfer(I2C_TypeDef* Open_I2C, uint8_t dev_addr, uint8_t *buffer, uint32_t cnt, uint32_t ptr, uint8_t ptrlen)
{
	uint32_t i;
	uint8_t rc = I2C_OK;
  //-----------------------------------------------------------------------------
  // parameter check
  //-----------------------------------------------------------------------------
  if ((buffer == 0) || (ptrlen > 4) || ((cnt | ptrlen) == 0))
  {
    return I2C_check_dev(Open_I2C, dev_addr); // may be used to check if device is responding
  }
  //-----------------------------------------------------------------------------
  rc = I2C_start(Open_I2C, dev_addr, I2C_Direction_Transmitter);
  if (rc == I2C_OK)
  {
    //---------------------------------------------------------------------------
    // write the register address pointer to the device
    //---------------------------------------------------------------------------
    if (ptrlen > 0)
    {
      for (i=1; i<=ptrlen; i++)
      {
        rc |= I2C_write(Open_I2C,((ptr >>(8*(ptrlen-i))) & 0xff));
      }
    }
    //---------------------------------------------------------------------------
    // write data to the device
    //---------------------------------------------------------------------------
    for (i=0; i<cnt; i++)
    {
      rc |= I2C_write(Open_I2C,*(buffer++));
    }
  }
  //-----------------------------------------------------------------------------
  I2C_GenerateSTOP(Open_I2C, ENABLE);                // stop the transmission
  return rc;
}


//===============================================================================
// Check if a device is responding with acknowledge on the given I2C-Bus address
//-------------------------------------------------------------------------------
static uint8_t I2C_check_dev(I2C_TypeDef* Open_I2C, uint8_t addr)
{
	uint32_t timeout;
  //-----------------------------------------------------------------------------
  timeout = I2C_TIMEOUT;
  while(I2C_GetFlagStatus(Open_I2C, I2C_FLAG_BUSY))
  {
    if((timeout--)==0)   // wait until I2C-Bus is not busy anymore
    {
      return I2C_ERROR;
    }
  }
  //-----------------------------------------------------------------------------
  I2C_GenerateSTART(Open_I2C, ENABLE);
  timeout = I2C_TIMEOUT;
  while(!I2C_CheckEvent(Open_I2C, I2C_EVENT_MASTER_MODE_SELECT))
  {
    if((timeout--)==0)  // wait while sending I2C-Bus START condition
    {
      I2C_GenerateSTOP(Open_I2C, ENABLE);
      return I2C_ERROR;
    }
  }
  //-----------------------------------------------------------------------------
  I2C_Send7bitAddress(Open_I2C, addr, I2C_Direction_Transmitter);
  timeout = I2C_TIMEOUT;
  while(!I2C_CheckEvent(Open_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
  {
    if((timeout--)==0)   // wait while sending slave address for write
    {
      I2C_GenerateSTOP(Open_I2C, ENABLE);
      return I2C_ERROR;
    }
  }
  //-----------------------------------------------------------------------------
  I2C_GenerateSTOP(Open_I2C, ENABLE);
  return I2C_OK;
}

//------------------------------------------------------------------
// This function issues a start condition and
// transmits the slave address + R/W bit
//
// Parameters:
//  I2Cx  --> the I2C peripheral e.g. I2C1
//  addr  --> the 7 bit slave address
//  rdwr  --> the tranmission direction can be:
//              I2C_Direction_Tranmitter for Master transmitter mode
//              I2C_Direction_Receiver for Master receiver
//------------------------------------------------------------------
static uint8_t I2C_start(I2C_TypeDef* I2Cx, uint8_t addr, uint8_t rdwr)
{
  uint32_t timeout = (100 * I2C_TIMEOUT);
  // wait until I2C1 is not busy anymore
  while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY))
  {
    if((timeout--)==0) return I2C_ERROR;
  }
  // Send I2C1 RESTART condition
  return I2C_restart(I2Cx, addr, rdwr);
}

//------------------------------------------------------------------
// This function issues a restart condition and
// transmits the slave address + R/W bit
//
// Parameters:
//  I2Cx  --> the I2C peripheral e.g. I2C1
//  addr  --> the 7 bit slave address
//  rdwr  --> the tranmission direction can be:
//              I2C_Direction_Tranmitter for Master transmitter mode
//              I2C_Direction_Receiver for Master receiver
//------------------------------------------------------------------
static uint8_t I2C_restart(I2C_TypeDef* I2Cx, uint8_t addr, uint8_t rdwr)
{
  uint32_t timeout = I2C_TIMEOUT;
  // Send I2C1 START condition
  I2C_GenerateSTART(I2Cx, ENABLE);
  // wait for I2C1 EV5 --> Slave has acknowledged start condition
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT))
  {
    if((timeout--)==0) return I2C_ERROR;
  }
  // Send slave Address for read or write
  I2C_Send7bitAddress(I2Cx, addr, rdwr);
  //------------------------------------------------------------------------
  // wait for I2C1 EV6, check if Slave has acknowledged Master transmitter
  // or Master receiver mode, depending on the transmission direction
  //------------------------------------------------------------------------
  timeout = I2C_TIMEOUT;
  if (rdwr==I2C_Direction_Transmitter)
  {
    while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
    {
      if((timeout--)==0) return I2C_ERROR;
    }
  }
  else if(rdwr==I2C_Direction_Receiver)
  {
    while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
    {
      if((timeout--)==0) return I2C_ERROR;
    }
  }
  return I2C_OK;
}

//------------------------------------------------------------------
// This function transmits one byte to the slave device
// Parameters:
//    I2Cx --> the I2C peripheral e.g. I2C1
//    data --> the data byte to be transmitted
//------------------------------------------------------------------
static uint8_t I2C_write(I2C_TypeDef* I2Cx, uint8_t data)
{
  uint32_t timeout = I2C_TIMEOUT;
  I2C_SendData(I2Cx, data);
  // wait for I2C1 EV8_2 --> byte has been transmitted
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
  {
    if((timeout--)==0) return I2C_ERROR;
  }
  return I2C_OK;
}

//------------------------------------------------------------------
// This function reads one byte from the slave device
// and acknowledges the byte (requests another byte)
//------------------------------------------------------------------
static uint8_t I2C_read_ack(I2C_TypeDef* I2Cx)
{
  uint32_t timeout = I2C_TIMEOUT;
  // enable acknowledge of recieved data
  I2C_AcknowledgeConfig(I2Cx, ENABLE);
  // wait until one byte has been received
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
  {
    if((timeout--)==0) return I2C_ERROR;
  }
  // read data from I2C data register and return data byte
  return I2C_ReceiveData(I2Cx);
}

//------------------------------------------------------------------
// This function reads one byte from the slave device
// and doesn't acknowledge the recieved data
//------------------------------------------------------------------
static uint8_t I2C_read_nack(I2C_TypeDef* I2Cx)
{
  uint32_t timeout = I2C_TIMEOUT;
  // disabe acknowledge of received data
  I2C_AcknowledgeConfig(I2Cx, DISABLE);
  // wait until one byte has been received
  while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
  {
    if((timeout--)==0) return I2C_ERROR;
  }
  // read data from I2C data register and return data byte
  return I2C_ReceiveData(I2Cx);
}
