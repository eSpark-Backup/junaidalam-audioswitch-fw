/*-----------------------------------------------------------------------*/
/* Low level disk I/O module skeleton for FatFs     (C)ChaN, 2013        */
/*-----------------------------------------------------------------------*/
/* If a working storage control module is available, it should be        */
/* attached to the FatFs via a glue function rather than modifying it.   */
/* This is an example of glue functions to attach various exsisting      */
/* storage control module to the FatFs module with a defined API.        */
/*-----------------------------------------------------------------------*/

#include <string.h>
#include "main.h"
#include "diskio.h"
#include "usbh_msc_scsi.h"
#include "usbh_msc_bot.h"
#include "stm32f4_sdio_sd.h"
#include "spiflash.h"

static volatile DSTATUS mSD_Stat = (STA_NODISK | STA_NOINIT);	/* Disk status */
static volatile BYTE LastWriteFlag = 0x00;

/*-----------------------------------------------------------------------*/
/* Initialize a Drive                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS disk_initialize (
	BYTE pdrv				/* Physical drive nmuber (0..) */
)
{
	DSTATUS Stat = STA_NOINIT;

	if(!pdrv)	//mSD
	{
		if(CARD_DETECT) mSD_Stat = (STA_NODISK | STA_NOINIT); 	/* Card not detected */
		else
		{
			//Check disk initialized
			if (SD_Init() == SD_OK)	mSD_Stat = 0x00;
			else mSD_Stat = STA_NOINIT;
		}
		Stat = mSD_Stat;
	}
#if	USB_ENABLED
	else if(pdrv == 1)	//USB
	{
		if(HCD_IsDeviceConnected(&USB_OTG_Core)) Stat = 0x00;
		else Stat = STA_NOINIT;
	}
#endif
#if NOR_ENABLED
	else if(pdrv == 2)	//NOR
	{
		if(bbNOR_CONNECT_STATE) Stat = 0x00;
		else Stat = STA_NODISK;
	}
#endif
	return Stat;
}



/*-----------------------------------------------------------------------*/
/* Get Disk Status                                                       */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
	BYTE pdrv		/* Physical drive nmuber (0..) */
)
{
	DSTATUS Stat = STA_NOINIT;

	if(!pdrv)
	{
		if(CARD_DETECT) mSD_Stat = (STA_NODISK | STA_NOINIT); 	/* Card not detected */
		Stat = mSD_Stat;
	}
#if	USB_ENABLED
	else if(pdrv == 1)	//USB
	{
		Stat = 0x00;
	}
#endif
#if NOR_ENABLED
	else if(pdrv == 2)	//NOR
	{
		Stat = 0x00;
	}
#endif
	return Stat;
}



/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/
DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Sector address (LBA) */
	UINT count		/* Number of sectors to read (1..128) */
)
{
	SD_Error Status = SD_OK;
	SDTransferState State;

	if (!count) return RES_PARERR;
	
	if(!pdrv)
	{
		if (mSD_Stat & STA_NOINIT) return RES_NOTRDY;

		if ((DWORD)buff & 3) {
			DRESULT res = RES_OK;
			DWORD scratch[_MIN_SS / 4];

			while (count--) {
				res = disk_read(0, (void *)scratch, sector++, 1);

				if (res != RES_OK) {
					break;
				}

				memcpy(buff, scratch, _MIN_SS);

				buff += _MIN_SS;
			}
			return res;
		}

		Status = SD_ReadMultiBlocks(buff, sector << 9, _MIN_SS, count);

		if (Status == SD_OK)
		{
			Status = SD_WaitReadOperation();
			while ((State = SD_GetStatus()) == SD_TRANSFER_BUSY);
			if ((State == SD_TRANSFER_ERROR) || (Status != SD_OK)) return RES_ERROR;
			else return RES_OK;
		}
	}
#if	USB_ENABLED
	else if(pdrv == 1)	//USB
	{
		BYTE USBstatus = USBH_MSC_BUSY;

		if(HCD_IsDeviceConnected(&USB_OTG_Core))
		{
			do
			{
				USBstatus = USBH_MSC_Read10(&USB_OTG_Core, buff, sector, _MIN_SS * count);
				USBH_MSC_HandleBOTXfer(&USB_OTG_Core ,&USB_Host);
				if(!HCD_IsDeviceConnected(&USB_OTG_Core)) return RES_ERROR;
			}
			while(USBstatus == USBH_MSC_BUSY );
		}
		if(USBstatus == USBH_MSC_OK) return RES_OK;
	}
#endif
#if NOR_ENABLED
	else if(pdrv == 2)	//NOR
	{
		sector *= _MAX_SS;
		count *= _MAX_SS;

		if(LastWriteFlag)
		{
			WriteDone();
			LastWriteFlag = 0x00;
		}

		SPIflashReadBytes(buff, sector, count);

		return RES_OK;
	}
#endif
	return RES_ERROR;
}

/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/

#if _USE_WRITE

DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber (0..) */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Sector address (LBA) */
	UINT count			/* Number of sectors to write (1..128) */
)
{
	SD_Error Status = SD_OK;
	SDTransferState State;

	if (!count) return RES_PARERR;
	
	if(!pdrv)
	{
		if (mSD_Stat & STA_NOINIT) return RES_NOTRDY;

		/* Return low level status */
		Status = SD_WriteMultiBlocks((uint8_t*)(buff), sector << 9, _MIN_SS, count);

		if (Status == SD_OK)
		{
			Status = SD_WaitWriteOperation();

			while ((State = SD_GetStatus()) == SD_TRANSFER_BUSY);

			if ((State == SD_TRANSFER_ERROR) || (Status != SD_OK)) return RES_ERROR;
			else return RES_OK;
		}
	}
#if	USB_ENABLED
	else if(pdrv == 1)	//USB
	{
		BYTE USBstatus = USBH_MSC_BUSY;

		if(HCD_IsDeviceConnected(&USB_OTG_Core))
		{
			do
			{
				USBstatus = USBH_MSC_Write10(&USB_OTG_Core, (BYTE*)buff, sector, _MIN_SS * count);
				USBH_MSC_HandleBOTXfer(&USB_OTG_Core ,&USB_Host);
				if(!HCD_IsDeviceConnected(&USB_OTG_Core)) return RES_ERROR;
			}
			while(USBstatus == USBH_MSC_BUSY );
		}
		if(USBstatus == USBH_MSC_OK) return RES_OK;
	}
#endif
#if NOR_ENABLED
	else if(pdrv == 2)	//NOR
	{
		sector *= _MAX_SS;
		SPIflashWriteSector((uint8_t*)buff, sector, count);
		LastWriteFlag = 0x01;
		return RES_OK;
	}
#endif
	return RES_ERROR;
}
#endif


/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/

#if _USE_IOCTL
DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	DWORD *result = (DWORD*)buff;

	if(!pdrv)
	{
		if(cmd == GET_SECTOR_SIZE) *result = _MIN_SS;
		if (mSD_Stat) return RES_NOTRDY;
	}
#if	USB_ENABLED
	else if(pdrv == 1)	//USB
	{
		if(cmd == GET_SECTOR_SIZE) *result = _MIN_SS;
		else if(cmd == GET_SECTOR_COUNT) *result = USBH_MSC_Param.MSCapacity;
		else if(cmd == GET_BLOCK_SIZE) *result = _MIN_SS;
	}
#endif
#if NOR_ENABLED
	else if(pdrv == 2)	//NOR
	{
		if(cmd == GET_SECTOR_SIZE) *result = _MAX_SS;
		else if(cmd == GET_SECTOR_COUNT) *result = NOR_SECTOR_COUNT;
		else if(cmd == GET_BLOCK_SIZE) *result = 1;
	}
#endif
	return RES_OK;
}
#endif

DWORD get_fattime(void) {
	/* Returns current time packed into a DWORD variable */
	return	  ((DWORD)(2020 - 1980) << 25)	/* Year 2019 */
			| ((DWORD)7 << 21)				/* Month 5 */
			| ((DWORD)15 << 16)				/* Mday 30 */
			| ((DWORD)0 << 11)				/* Hour 0 */
			| ((DWORD)0 << 5)				/* Min 0 */
			| ((DWORD)0 >> 1);				/* Sec 0 */
}

/*-----------------------------------------------------------------------*/
/* Device Timer Driven Procedure                                         */
/*-----------------------------------------------------------------------*/
/* This function must be called by timer interrupt in period of 1ms      */

void disk_timerproc (void)
{

	if(CARD_DETECT) mSD_Stat = (STA_NODISK | STA_NOINIT); 	/* Card not detected */
	else mSD_Stat &= ~STA_NODISK;
}
