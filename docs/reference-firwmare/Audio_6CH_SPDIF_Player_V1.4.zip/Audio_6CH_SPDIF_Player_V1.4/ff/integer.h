/*-------------------------------------------*/
/* Integer type definitions for FatFs module */
/*-------------------------------------------*/

#ifndef _INTEGER
#define _INTEGER

#ifdef _WIN32	/* FatFs development platform */

#include <windows.h>
#include <tchar.h>

#else			/* Embedded platform */

/* These types must be 16-bit, 32-bit or larger integer */
typedef int				INT;
typedef unsigned int	UINT;

/* These types must be 8-bit integer */
typedef char			CHAR;
typedef unsigned char	UCHAR;
typedef unsigned char	BYTE;

/* These types must be 16-bit integer */
typedef short			SHORT;
typedef unsigned short	USHORT;
typedef unsigned short	WORD;
typedef unsigned short	WCHAR;

/* These types must be 32-bit integer */
typedef long			LONG;
typedef unsigned long	ULONG;
typedef unsigned long	DWORD;

/* Specify an extension for GCC based compilers */
#if defined(__GNUC__)
#define __EXTENSION __extension__
#else
#define __EXTENSION
#endif

__EXTENSION typedef unsigned long long  UINT64;

typedef union
{
	BYTE Val;
    struct
    {
        __EXTENSION BYTE b0:1;
        __EXTENSION BYTE b1:1;
        __EXTENSION BYTE b2:1;
        __EXTENSION BYTE b3:1;
        __EXTENSION BYTE b4:1;
        __EXTENSION BYTE b5:1;
        __EXTENSION BYTE b6:1;
        __EXTENSION BYTE b7:1;
    } bits;
} UINT8_VAL, UINT8_BITS;

typedef union
{
	WORD Val;
	BYTE v[2];
    struct
    {
		BYTE LB;
		BYTE HB;
    } byte;
    struct
    {
        __EXTENSION BYTE b0:1;
        __EXTENSION BYTE b1:1;
        __EXTENSION BYTE b2:1;
        __EXTENSION BYTE b3:1;
        __EXTENSION BYTE b4:1;
        __EXTENSION BYTE b5:1;
        __EXTENSION BYTE b6:1;
        __EXTENSION BYTE b7:1;
        __EXTENSION BYTE b8:1;
        __EXTENSION BYTE b9:1;
        __EXTENSION BYTE b10:1;
        __EXTENSION BYTE b11:1;
        __EXTENSION BYTE b12:1;
        __EXTENSION BYTE b13:1;
        __EXTENSION BYTE b14:1;
        __EXTENSION BYTE b15:1;
    } bits;
} UINT16_VAL, UINT16_BITS;

typedef union
{
	DWORD Val;
	WORD w[2];
	BYTE  v[4];
    struct
    {
		WORD LW;
		WORD HW;
    } word;
    struct
    {
    	BYTE LB;
    	BYTE HB;
    	BYTE UB;
    	BYTE MB;
    } byte;
    struct
    {
    	WORD low;
    	WORD high;
    }wordUnion;
    struct
    {
        __EXTENSION BYTE b0:1;
        __EXTENSION BYTE b1:1;
        __EXTENSION BYTE b2:1;
        __EXTENSION BYTE b3:1;
        __EXTENSION BYTE b4:1;
        __EXTENSION BYTE b5:1;
        __EXTENSION BYTE b6:1;
        __EXTENSION BYTE b7:1;
        __EXTENSION BYTE b8:1;
        __EXTENSION BYTE b9:1;
        __EXTENSION BYTE b10:1;
        __EXTENSION BYTE b11:1;
        __EXTENSION BYTE b12:1;
        __EXTENSION BYTE b13:1;
        __EXTENSION BYTE b14:1;
        __EXTENSION BYTE b15:1;
        __EXTENSION BYTE b16:1;
        __EXTENSION BYTE b17:1;
        __EXTENSION BYTE b18:1;
        __EXTENSION BYTE b19:1;
        __EXTENSION BYTE b20:1;
        __EXTENSION BYTE b21:1;
        __EXTENSION BYTE b22:1;
        __EXTENSION BYTE b23:1;
        __EXTENSION BYTE b24:1;
        __EXTENSION BYTE b25:1;
        __EXTENSION BYTE b26:1;
        __EXTENSION BYTE b27:1;
        __EXTENSION BYTE b28:1;
        __EXTENSION BYTE b29:1;
        __EXTENSION BYTE b30:1;
        __EXTENSION BYTE b31:1;
    } bits;
} UINT32_VAL, UINT32_BITS;

typedef union
{
    UINT64 Val;
    DWORD d[2];
    WORD w[4];
    BYTE v[8];
    struct
    {
    	DWORD LD;
    	DWORD HD;
    } dword;
    struct
    {
    	WORD LW;
    	WORD HW;
    	WORD UW;
    	WORD MW;
    } word;
    struct
    {
        __EXTENSION BYTE b0:1;
        __EXTENSION BYTE b1:1;
        __EXTENSION BYTE b2:1;
        __EXTENSION BYTE b3:1;
        __EXTENSION BYTE b4:1;
        __EXTENSION BYTE b5:1;
        __EXTENSION BYTE b6:1;
        __EXTENSION BYTE b7:1;
        __EXTENSION BYTE b8:1;
        __EXTENSION BYTE b9:1;
        __EXTENSION BYTE b10:1;
        __EXTENSION BYTE b11:1;
        __EXTENSION BYTE b12:1;
        __EXTENSION BYTE b13:1;
        __EXTENSION BYTE b14:1;
        __EXTENSION BYTE b15:1;
        __EXTENSION BYTE b16:1;
        __EXTENSION BYTE b17:1;
        __EXTENSION BYTE b18:1;
        __EXTENSION BYTE b19:1;
        __EXTENSION BYTE b20:1;
        __EXTENSION BYTE b21:1;
        __EXTENSION BYTE b22:1;
        __EXTENSION BYTE b23:1;
        __EXTENSION BYTE b24:1;
        __EXTENSION BYTE b25:1;
        __EXTENSION BYTE b26:1;
        __EXTENSION BYTE b27:1;
        __EXTENSION BYTE b28:1;
        __EXTENSION BYTE b29:1;
        __EXTENSION BYTE b30:1;
        __EXTENSION BYTE b31:1;
        __EXTENSION BYTE b32:1;
        __EXTENSION BYTE b33:1;
        __EXTENSION BYTE b34:1;
        __EXTENSION BYTE b35:1;
        __EXTENSION BYTE b36:1;
        __EXTENSION BYTE b37:1;
        __EXTENSION BYTE b38:1;
        __EXTENSION BYTE b39:1;
        __EXTENSION BYTE b40:1;
        __EXTENSION BYTE b41:1;
        __EXTENSION BYTE b42:1;
        __EXTENSION BYTE b43:1;
        __EXTENSION BYTE b44:1;
        __EXTENSION BYTE b45:1;
        __EXTENSION BYTE b46:1;
        __EXTENSION BYTE b47:1;
        __EXTENSION BYTE b48:1;
        __EXTENSION BYTE b49:1;
        __EXTENSION BYTE b50:1;
        __EXTENSION BYTE b51:1;
        __EXTENSION BYTE b52:1;
        __EXTENSION BYTE b53:1;
        __EXTENSION BYTE b54:1;
        __EXTENSION BYTE b55:1;
        __EXTENSION BYTE b56:1;
        __EXTENSION BYTE b57:1;
        __EXTENSION BYTE b58:1;
        __EXTENSION BYTE b59:1;
        __EXTENSION BYTE b60:1;
        __EXTENSION BYTE b61:1;
        __EXTENSION BYTE b62:1;
        __EXTENSION BYTE b63:1;
    } bits;
} UINT64_VAL;

#endif

#endif
